import 'package:flutter/material.dart';

class AddeventButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final Color textColor;
  final VoidCallback onPressed;

  const AddeventButton({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    required this.textColor,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      child: Container(
        padding: const EdgeInsets.fromLTRB(25, 10, 25, 10),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: color),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(width: 5),
            Text(
              title,
              style: TextStyle(
                color: textColor,
              ),
            ),
            Icon(
              icon,
              color: textColor,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}
