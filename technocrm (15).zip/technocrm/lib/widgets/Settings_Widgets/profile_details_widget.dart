import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Settings_Widgets/input_feild_settings_widget.dart';

class ProfileDetailsWidget extends StatelessWidget {
  const ProfileDetailsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(40, 0, 30, 50),
      child: Column(
        children: [
          Row(
            children: [
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.06,
                    child: InputFeildSettingsWidget(
                      labelText: 'Your Name',
                      hintText: 'Mr',
                      isDropdown: true,
                      dropdownItems: const [
                        DropdownMenuItem(
                          value: '--',
                          child: Row(
                            children: [
                              Text('--'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Mrs',
                          child: Row(
                            children: [
                              Text('Mrs'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Dr',
                          child: Row(
                            children: [
                              Text('Dr'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (value) {},
                      contentPadding: const EdgeInsets.all(0),
                    ),
                  ),
                  const SizedBox(
                    width: 4,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.22,
                    child: const InputFeildSettingsWidget(
                      labelText: '',
                      hintText: '',
                      contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                width: 15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.23,
                child: const InputFeildSettingsWidget(
                  labelText: 'Your Email*',
                  hintText: 'abc.company@gmail.com',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.23,
                child: const InputFeildSettingsWidget(
                  labelText: 'Your Password',
                  hintText: '',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.28,
                child: InputFeildSettingsWidget(
                  labelText: 'Country',
                  hintText: '--',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(
                      value: '--',
                      child: Row(
                        children: [
                          Text('--'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Mrs',
                      child: Row(
                        children: [
                          Text('Mrs'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Dr',
                      child: Row(
                        children: [
                          Text('Dr'),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.05,
                    child: InputFeildSettingsWidget(
                      labelText: 'Mobile',
                      hintText: '+91',
                      isDropdown: true,
                      dropdownItems: const [
                        DropdownMenuItem(
                          value: '--',
                          child: Row(
                            children: [
                              Text('--'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Mrs',
                          child: Row(
                            children: [
                              Text('Mrs'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Dr',
                          child: Row(
                            children: [
                              Text('Dr'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (value) {},
                      contentPadding: const EdgeInsets.all(0),
                    ),
                  ),
                  const SizedBox(
                    width: 4,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.18,
                    child: const InputFeildSettingsWidget(
                      labelText: '',
                      hintText: '',
                      contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                width: 15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.23,
                child: InputFeildSettingsWidget(
                  labelText: 'Channel Language',
                  hintText: '--',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(
                      value: '--',
                      child: Row(
                        children: [
                          Text('--'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Mrs',
                      child: Row(
                        children: [
                          Text('Mrs'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Dr',
                      child: Row(
                        children: [
                          Text('Dr'),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.28,
                child: InputFeildSettingsWidget(
                  labelText: 'Gender',
                  hintText: 'Male',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(
                      value: '--',
                      child: Row(
                        children: [
                          Text('--'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Mrs',
                      child: Row(
                        children: [
                          Text('Mrs'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Dr',
                      child: Row(
                        children: [
                          Text('Dr'),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.24,
                child: const InputFeildSettingsWidget(
                  labelText: 'Date of Birth',
                  hintText: '12-01-2023',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.23,
                child: InputFeildSettingsWidget(
                  labelText: 'Maritial Stauts',
                  hintText: 'Single',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(
                      value: '--',
                      child: Row(
                        children: [
                          Text('--'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Mrs',
                      child: Row(
                        children: [
                          Text('Mrs'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'Dr',
                      child: Row(
                        children: [
                          Text('Dr'),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.77,
                child: const InputFeildSettingsWidget(
                  labelText: 'Your Address',
                  hintText: '',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 60),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.77,
                child: const InputFeildSettingsWidget(
                  labelText: 'About',
                  hintText: 'e.g. 123, My Street, Kingston, New York 12401',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 100),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 0, 70, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomButtonWidget(
                  title: 'Cancel',
                  color: AppColors.bgColor,
                  textColor: Colors.grey,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: Icons.close,
                ),
                CustomButtonWidget(
                  title: 'Save',
                  color: Colors.blue,
                  textColor: Colors.white,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: Icons.check,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
