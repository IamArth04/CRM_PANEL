import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/activity_attendance_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/circle_attendance_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/models_Attendance/clock_attendance_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/profile_attendance_widget.dart';

class PresentListEmployeeAttendancescreenWidget extends StatefulWidget {
  const PresentListEmployeeAttendancescreenWidget({super.key});

  @override
  State<PresentListEmployeeAttendancescreenWidget> createState() =>
      _PresentListEmployeeAttendancescreenWidgetState();
}

class _PresentListEmployeeAttendancescreenWidgetState
    extends State<PresentListEmployeeAttendancescreenWidget> {
  void _onPresentListTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Attendence Details",
            style: TextStyle(
              fontSize: 26,
              color: AppColors.titleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: const SingleChildScrollView(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    ProfileAttendanceScreenWidget(),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(padding: EdgeInsets.fromLTRB(10, 0, 0, 0)),
                        Text(
                          "Date",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          "17-11-2023",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    ClockAttendanceScreenTextWidget(
                      label: 'Clock In',
                      time: '10:00 am',
                      labelColor: Colors.grey,
                      timeColor: Colors.black,
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    CircleAttendanceScreenWidget(),
                    SizedBox(
                      height: 20,
                    ),
                    ClockAttendanceScreenTextWidget(
                      label: 'Clock Out',
                      time: '07:02 pm',
                      labelColor: Colors.grey,
                      timeColor: Colors.black,
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    ActivityAttendanceScreenWidget(),
                  ],
                )
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(60, 0, 30, 0),
      padding: const EdgeInsets.fromLTRB(0, 15, 10, 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: Colors.white,
      ),
      child: Row(
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 17,
                backgroundImage: AssetImage('assets/user.png'),
              ),
              const SizedBox(
                width: 10,
              ),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Harsh Verma',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    'UI/UX',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                width: 10,
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "It's You",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(
                width: 100,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "-",
                    style: TextStyle(fontSize: 22, color: Colors.grey),
                  ),
                  const SizedBox(
                    width: 25,
                  ),
                  const Text(
                    "-",
                    style: TextStyle(fontSize: 22, color: Colors.grey),
                  ),
                  const SizedBox(
                    width: 7,
                  ),
                  IconButton(
                      onPressed: () {
                        _onPresentListTap(context);
                      },
                      icon: const Icon(
                        Icons.check,
                        color: Colors.blue,
                        size: 20,
                      )),
                  IconButton(
                      onPressed: () {
                        _onPresentListTap(context);
                      },
                      icon: const Icon(
                        Icons.check,
                        color: Colors.blue,
                        size: 20,
                      )),
                  IconButton(
                      onPressed: () {
                        _onPresentListTap(context);
                      },
                      icon: const Icon(
                        Icons.check,
                        color: Colors.blue,
                        size: 20,
                      )),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
