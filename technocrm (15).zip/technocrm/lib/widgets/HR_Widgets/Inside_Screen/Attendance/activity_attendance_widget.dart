import 'package:flutter/material.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/models_Attendance/clock_attendance_widget.dart';

class ActivityAttendanceScreenWidget extends StatelessWidget {
  const ActivityAttendanceScreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(170, 0, 0, 130),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Activity",
            style: TextStyle(
              fontSize: 20,
              color: Colors.black,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(
            height: 40,
          ),
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
              ),
              const ClockAttendanceScreenTextWidget(
                label: "Clock In",
                time: "17-11-2023 10:00 am",
                labelColor: Colors.black,
                timeColor: Colors.grey,
              ),
            ],
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(3, 0, 0, 0),
            width: 4,
            height: 100,
            color: Colors.blue,
          ),
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
              ),
              const ClockAttendanceScreenTextWidget(
                label: "Clock Out",
                time: "17-11-2023 10:00 am",
                labelColor: Colors.black,
                timeColor: Colors.grey,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
