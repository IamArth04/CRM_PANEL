import 'package:flutter/material.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/models_Attendance/date_day_column_widget.dart';

class EmployeesDatelistAttendencescreenWidget extends StatelessWidget {
  const EmployeesDatelistAttendencescreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    List<int> dates = List.generate(30, (index) => index + 1);

    return Container(
      margin: const EdgeInsets.fromLTRB(60, 0, 30, 0),
      padding: const EdgeInsets.fromLTRB(20, 10, 100, 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: Colors.white,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Employee",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ...dates.map((date) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: DateDayColumn(date: date),
                  )),
            ],
          )
        ],
      ),
    );
  }
}
