// import 'package:flutter/material.dart';

// class CircleAttendanceScreenWidget extends StatelessWidget {
//   const CircleAttendanceScreenWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.fromLTRB(200, 10, 0, 0),
//       width: 125,
//       height: 125,
//       decoration: BoxDecoration(
//         shape: BoxShape.circle,
//         border: Border.all(
//           color: Colors.blue,
//           width: 2.0,
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

class CircleAttendanceScreenWidget extends StatelessWidget {
  const CircleAttendanceScreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(200, 10, 0, 0),
          width: 125,
          height: 125,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: Colors.blue,
              width: 2.0,
            ),
          ),
        ),
        const Positioned(
          top: 140,
          left: 200,
          child: Text(
            'Attendance',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
