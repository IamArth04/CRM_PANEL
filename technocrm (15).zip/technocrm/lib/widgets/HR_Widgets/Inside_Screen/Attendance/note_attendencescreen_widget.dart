import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class NoteAttendencescreenWidget extends StatelessWidget {
  const NoteAttendencescreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(60, 10, 0, 0),
      child: Row(
        children: [
          Text(
            "Note :",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 20,
          ),
          const Icon(
            Icons.star,
            color: Colors.amber,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Holiday",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.calendar_today_outlined,
            color: Colors.red,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Day Off",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.check,
            color: Colors.blue,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Present",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.close,
            color: Colors.grey,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Absent",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.flight_takeoff_outlined,
            color: Colors.red,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "On Leave",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.star_half,
            color: Colors.red,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Half Day",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Text(
            "|",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 22,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          const Icon(
            Icons.error_outlined,
            color: Colors.blue,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            "Late",
            style: TextStyle(
              color: AppColors.titleColor,
            ),
          ),
        ],
      ),
    );
  }
}
