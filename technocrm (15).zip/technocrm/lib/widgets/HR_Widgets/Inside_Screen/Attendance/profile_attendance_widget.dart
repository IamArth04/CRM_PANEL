import 'package:flutter/material.dart';

class ProfileAttendanceScreenWidget extends StatelessWidget {
  const ProfileAttendanceScreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Image.asset('assets/user.png'),
          ],
        ),
        const SizedBox(
          width: 10,
        ),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Harsh Verma",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 2, 28, 49),
              ),
            ),
            Text(
              "UI/UX Designer",
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            )
          ],
        )
      ],
    );
  }
}
