import 'package:flutter/material.dart';

class DateDayColumn extends StatelessWidget {
  final int date;

  const DateDayColumn({super.key, required this.date});

  @override
  Widget build(BuildContext context) {
    List<String> daysOfWeek = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    String day = daysOfWeek[(date - 1) % 7];

    return Column(
      children: [
        Text(
          date.toString(),
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 14,
            fontWeight: FontWeight.w400,
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        Text(
          day,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}
