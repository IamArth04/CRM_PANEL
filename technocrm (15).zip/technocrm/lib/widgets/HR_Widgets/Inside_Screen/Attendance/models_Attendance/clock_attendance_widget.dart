import 'package:flutter/material.dart';

class ClockAttendanceScreenTextWidget extends StatelessWidget {
  final String label;
  final String time;
  final Color labelColor;
  final Color timeColor;
  // final EdgeInsetsGeometry margin;

  const ClockAttendanceScreenTextWidget({
    super.key,
    required this.label,
    required this.time,
    required this.labelColor,
    required this.timeColor,
    // required this.margin,
    // this.labelColor = Colors.grey,
    // this.timeColor = Colors.black,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(25, 0, 0, 0),
      width: MediaQuery.of(context).size.width * 0.30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 18,
              color: labelColor,
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 18,
              color: timeColor,
            ),
          )
        ],
      ),
    );
  }
}
