import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/page_titleWidget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/drawer_head_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/employees_datelist_attendencescreen_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/list_attendancescreen.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/note_attendencescreen_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';

class AttendenceScreen extends StatelessWidget {
  const AttendenceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                PageTitleWidget(
                  titleText: "Attendence",
                  subtitleText: "Attendence",
                ),
                NotitficationWidget(),
              ],
            ),
            const AttendanceScreenHeadDrawerWidget(),
            const SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 10, 0),
              child: Row(
                children: [
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {},
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const NoteAttendencescreenWidget(),
            const SizedBox(
              height: 10,
            ),
            const EmployeesDatelistAttendencescreenWidget(),
            const SizedBox(
              height: 5,
            ),
            const PresentListEmployeeAttendancescreenWidget(),
          ],
        ),
      ),
    );
  }
}
