import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Appreciation/info_appr_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';

class HomeApprWidget extends StatefulWidget {
  const HomeApprWidget({super.key});

  @override
  State<HomeApprWidget> createState() => _HomeApprWidgetState();
}

class _HomeApprWidgetState extends State<HomeApprWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(
                    titleText: "Appreciation", subtitleText: "Appreciation"),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const LeadsHeadtitleWidget(),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 0, 10, 0),
              child: Row(
                children: [
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {},
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const InfoApprWidget(),
          ],
        ),
      ),
    );
  }
}
