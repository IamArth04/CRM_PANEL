import 'package:flutter/material.dart';

class NavigationHRItem extends StatelessWidget {
  final String text;
  final bool isTapped;
  final Color color;
  final VoidCallback onTap;

  const NavigationHRItem({
    super.key,
    required this.text,
    required this.onTap,
    required this.isTapped,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 40.0, top: 8.0, bottom: 8.0),
      child: InkWell(
        onTap: onTap,
        child: Text(
          text,
          style: TextStyle(fontSize: 16, color: color),
        ),
      ),
    );
  }
}
