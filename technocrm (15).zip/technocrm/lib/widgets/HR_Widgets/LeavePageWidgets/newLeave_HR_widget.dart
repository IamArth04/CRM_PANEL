import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/HR_Widgets/LeavePageWidgets/inputfeild_hr_widget.dart';

class NewleaveHrWidget extends StatelessWidget {
  const NewleaveHrWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const InputFieldHRWidget(
              labelText: 'Name*',
              hintText: '',
              contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            ),
            const SizedBox(width: 20),
            InputFieldHRWidget(
              labelText: 'Leave Type*',
              hintText: '--',
              isDropdown: true,
              dropdownItems: const [
                DropdownMenuItem(value: '--', child: Text('--')),
                DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
              ],
              onChanged: (value) {},
              contentPadding: const EdgeInsets.all(0),
            ),
            const SizedBox(width: 13),
            Container(
              padding: const EdgeInsets.fromLTRB(0, 0, 30, 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Select Duration",
                    style: TextStyle(
                      fontSize: 18,
                      color: AppColors.titleColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(
                            Icons.circle_outlined,
                          )),
                      const Text(
                        "Full Day",
                        style: TextStyle(
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.circle_outlined)),
                      const Text(
                        "Multiple",
                        style: TextStyle(
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.circle_outlined)),
                      const Text(
                        "First Half",
                        style: TextStyle(
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.circle_outlined)),
                      const Text(
                        "Second Half",
                        style: TextStyle(
                          fontSize: 14,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
        const SizedBox(height: 40),
        const InputFieldHRWidget(
          labelText: 'Date',
          hintText: '',
          contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
        ),
        const SizedBox(height: 40),
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: InputFieldHRWidget(
                labelText: 'Reason for absence*',
                hintText: 'e.g. Feeling not well',
                keyboardType: TextInputType.text,
                contentPadding: EdgeInsets.fromLTRB(10, 5, 0, 100),
              ),
            ),
          ],
        ),
        const SizedBox(height: 40),
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: InputFieldHRWidget(
                labelText: 'Reason for absence*',
                hintText: 'Choose a file',
                keyboardType: TextInputType.text,
                contentPadding: EdgeInsets.fromLTRB(10, 5, 0, 170),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
