import 'package:flutter/material.dart';

class HeadTicketsInfoWidget extends StatelessWidget {
  const HeadTicketsInfoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
          margin: const EdgeInsets.fromLTRB(50, 0, 10, 0),
          width: MediaQuery.of(context).size.width * 0.12,
          color: Colors.white,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Total Tickets",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              Icon(
                Icons.bolt,
                color: Colors.grey,
              )
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
          margin: const EdgeInsets.fromLTRB(50, 0, 10, 0),
          width: MediaQuery.of(context).size.width * 0.12,
          color: Colors.white,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Closed",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              Icon(
                Icons.bolt,
                color: Colors.grey,
              )
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
          margin: const EdgeInsets.fromLTRB(50, 0, 10, 0),
          width: MediaQuery.of(context).size.width * 0.12,
          color: Colors.white,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Open Tickets",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              Icon(
                Icons.bolt,
                color: Colors.grey,
              )
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
          margin: const EdgeInsets.fromLTRB(50, 0, 10, 0),
          width: MediaQuery.of(context).size.width * 0.12,
          color: Colors.white,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Pending Tickets",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              Icon(
                Icons.bolt,
                color: Colors.grey,
              )
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
          margin: const EdgeInsets.fromLTRB(50, 0, 10, 0),
          width: MediaQuery.of(context).size.width * 0.12,
          color: Colors.white,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Resolved Tickets",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              Icon(
                Icons.bolt,
                color: Colors.grey,
              )
            ],
          ),
        )
      ],
    );
    // );
  }
}
