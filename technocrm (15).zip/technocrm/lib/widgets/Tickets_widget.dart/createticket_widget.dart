import 'package:flutter/material.dart';
import 'package:technocrm/widgets/Expenses_Widgets/model_expenses/inputfeild_expenses_model.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/models_task/task_inputfeild_work_model.dart';

class CreateticketWidget extends StatelessWidget {
  const CreateticketWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const InputfeildExpensesModel(
              labelText: 'Assignn Group*',
              hintText: '',
              contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            ),
            const SizedBox(width: 40),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.30,
              child: InputfeildExpensesModel(
                labelText: 'Agent',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                  DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                  DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ),
          ],
        ),
        const SizedBox(height: 25),
        const Row(
          children: [
            Expanded(
              child: TaskInputfeildWorkModel(
                labelText: 'Ticket Subject*',
                hintText: '',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              ),
            )
          ],
        ),
        const SizedBox(
          height: 25,
        ),
        const Row(
          children: [
            Expanded(
              child: TaskInputfeildWorkModel(
                labelText: 'Description',
                hintText: '',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 80),
              ),
            )
          ],
        )
      ],
    );
  }
}
