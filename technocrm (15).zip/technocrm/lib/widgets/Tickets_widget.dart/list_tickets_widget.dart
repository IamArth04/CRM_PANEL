import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_bottombutton_widget.dart';

class ListTicketsWidget extends StatefulWidget {
  const ListTicketsWidget({super.key});

  @override
  State<ListTicketsWidget> createState() => _ListTicketsWidgetState();
}

class _ListTicketsWidgetState extends State<ListTicketsWidget> {
  List<Map<String, dynamic>> projectDetails = [
    {
      "CheckBox": false,
      "id": "",
      "Item Name": "",
      "Price": "",
      "Employees": "",
      "Purchase From": "",
      "Purchase Date": "",
      "Status": "",
      "Action": "View",
    },
  ];

  bool _selectAll = false;

  void _toggleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      for (var detail in projectDetails) {
        detail["CheckBox"] = _selectAll;
      }
    });
  }

  void _toggleCheckbox(int index, bool? value) {
    setState(() {
      projectDetails[index]["CheckBox"] = value ?? false;
      _selectAll = projectDetails.every((detail) => detail["CheckBox"] == true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(25, 10, 0, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(5, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Transform.scale(
                    scale: 0.7,
                    child: Checkbox(
                      value: _selectAll,
                      onChanged: _toggleSelectAll,
                      activeColor: Colors.grey,
                      checkColor: Colors.white,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "id",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Item Name",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Price",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Employees",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Purchase From",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Purchase Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Status",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Action",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < projectDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 10, 7, 0),
              child: Container(
                margin: const EdgeInsets.fromLTRB(5, 0, 20, 0),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Text(
                        projectDetails[i]["id"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Item Name"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Price"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        projectDetails[i]["Employees"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        projectDetails[i]["Purchase From"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        projectDetails[i]["Purchase Date"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(
                        projectDetails[i]["Status"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert),
                        onSelected: (String value) {
                          if (value == 'View') {}
                        },
                        itemBuilder: (BuildContext context) {
                          return [
                            PopupMenuItem<String>(
                              value: 'View',
                              child: Center(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 20),
                                  decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'View',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ];
                        },
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        ),
                        color: Colors.white,
                        elevation: 4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Previous",
                        color: AppColors.bgColor),
                    const SizedBox(
                      width: 20,
                    ),
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Next",
                        color: AppColors.bgColor),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
