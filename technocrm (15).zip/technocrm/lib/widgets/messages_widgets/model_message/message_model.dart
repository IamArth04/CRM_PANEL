import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class MessageModel extends StatelessWidget {
  final String imagePath;
  final String headingText;
  final String smessage;
  final String nmessage;
  final String time;

  const MessageModel({
    super.key,
    required this.imagePath,
    required this.headingText,
    this.smessage = "Hey! Did you finish the Hi-FI wireframes for flora",
    this.nmessage = "app design?",
    this.time = "5.30 PM",
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(2),
                  border: Border.all(color: AppColors.bgColor, width: 2),
                  image: DecorationImage(
                    image: AssetImage(imagePath),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            width: 20,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 7, 0, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  headingText,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  smessage,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
                Text(
                  nmessage,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    const Icon(
                      Icons.access_time_outlined,
                      color: Color.fromARGB(255, 177, 184, 188),
                      size: 16,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "Today",
                      style: TextStyle(
                        fontSize: 12,
                        color: Color.fromARGB(255, 177, 184, 188),
                      ),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Text(
                      "|",
                      style: TextStyle(
                        fontSize: 16,
                        color: Color.fromARGB(255, 177, 184, 188),
                      ),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      time,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color.fromARGB(255, 177, 184, 188),
                      ),
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
