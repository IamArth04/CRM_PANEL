import 'package:flutter/material.dart';
import 'package:technocrm/widgets/messages_widgets/model_message/inputfeild_messages_model.dart';

class NewConversationMessageWidget extends StatelessWidget {
  const NewConversationMessageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.30,
              child: InputfeildMessagesModel(
                labelText: '',
                hintText: 'Choose Member*',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(
                    value: '--',
                    child: Row(
                      children: [
                        Text('--'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 1',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar1.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Project Name'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 2',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar2.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 2'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 3',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar3.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 3'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 4',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar4.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 4'),
                      ],
                    ),
                  ),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ),
            SizedBox(
              height: 50,
              width: 60,
              child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    border: Border.all(
                      color: Colors.grey,
                      width: 2,
                    ),
                    borderRadius: const BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0),
                    ),
                  ),
                  child: const CircleAvatar(
                    radius: 15,
                    backgroundImage: AssetImage('assets/client.png'),
                  )),
            ),
          ],
        ),
        const SizedBox(
          height: 30,
        ),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.45,
          child: const InputfeildMessagesModel(
            labelText: 'Message*',
            hintText: '',
            contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
          ),
        ),
        const SizedBox(
          height: 30,
        ),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.45,
          child: const InputfeildMessagesModel(
            labelText: 'Add File',
            hintText: '',
            contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 80),
          ),
        )
      ],
    );
  }
}
