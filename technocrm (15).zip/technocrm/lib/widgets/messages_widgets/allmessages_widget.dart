import 'package:flutter/material.dart';
import 'package:technocrm/widgets/messages_widgets/model_message/message_model.dart';

class AllmessagesWidget extends StatelessWidget {
  const AllmessagesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(30, 15, 0, 20),
      margin: const EdgeInsets.fromLTRB(40, 15, 0, 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "All Messages",
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 50, 20),
                child: Row(
                  children: [
                    SizedBox(
                      width: 350,
                      height: 40,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(5.0),
                            bottomLeft: Radius.circular(5.0),
                          ),
                        ),
                        child: const TextField(
                          decoration: InputDecoration(
                            hintText: 'Search or start a new chat',
                            hintStyle: TextStyle(
                              color: Colors.grey,
                            ),
                            contentPadding: EdgeInsets.fromLTRB(5, 0, 0, 5),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 40.0,
                      width: 60.0,
                      child: DecoratedBox(
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(5.0),
                            bottomRight: Radius.circular(5.0),
                          ),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.search, color: Colors.white),
                          onPressed: () {},
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              const MessageModel(
                  imagePath: "assets/avatar1.png",
                  headingText: "Jennifer Markus"),
              const SizedBox(
                height: 20,
              ),
              const MessageModel(
                  imagePath: "assets/avatar2.png", headingText: "Iva Ryan"),
              const SizedBox(
                height: 20,
              ),
              const MessageModel(
                  imagePath: "assets/avatar3.png", headingText: "Jerry Helfer"),
              const SizedBox(
                height: 20,
              ),
              const MessageModel(
                  imagePath: "assets/avatar4.png", headingText: "David Elson"),
              const SizedBox(
                height: 20,
              ),
              const MessageModel(
                  imagePath: "assets/avatar5.png", headingText: "Mary Freund"),
            ],
          )
        ],
      ),
    );
  }
}
