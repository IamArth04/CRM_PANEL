import 'package:flutter/material.dart';

class CommonCardWidget extends StatelessWidget {
  final String title;
  final double width;
  final String content;

  const CommonCardWidget(
      {super.key,
      required this.title,
      required this.width,
      required this.content});

  @override
  Widget build(BuildContext context) {
    return Container(
      //width: width,
      padding: const EdgeInsets.all(16.0),
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8.0),
          Text(content),
        ],
      ),
    );
  }
}
