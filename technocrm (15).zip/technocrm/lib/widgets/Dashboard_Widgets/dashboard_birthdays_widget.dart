import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class birthdaywidget extends StatelessWidget {
  const birthdaywidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15), color: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Birthday",
            style: TextStyle(
              fontSize: 18,
              color: AppColors.titleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  CircleAvatar(
                    radius: 17,
                    backgroundImage: AssetImage('assets/jackson.png'),
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  Column(
                    children: [
                      Text(
                        "Jackson D",
                        style: TextStyle(color: Colors.black),
                      ),
                      Text(
                        "Manager",
                        style: TextStyle(color: Colors.grey),
                      )
                    ],
                  ),
                ],
              ),
              const Row(
                children: [
                  Icon(
                    Icons.cake_outlined,
                    color: Color.fromARGB(255, 5, 43, 85),
                  ),
                  SizedBox(
                    width: 3,
                  ),
                  Text(
                    "25 Nov",
                    style: TextStyle(
                        fontSize: 12,
                        color: Color.fromARGB(255, 5, 43, 85),
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  "2 Weeks After",
                  style: TextStyle(fontSize: 12),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
