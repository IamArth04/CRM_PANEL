import 'package:flutter/material.dart';

class UserInfoWidget extends StatelessWidget {
  final double width;

  const UserInfoWidget({super.key, required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      //width: width,
      padding: const EdgeInsets.all(16.0),
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Welcome Harsh!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Row(
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage('https://example.com/image.jpg'),
                radius: 30,
              ),
              SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Harsh Verma',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('UI/UX Designer'),
                ],
              ),
              Spacer(),
              Text('Employee Id: 20'),
            ],
          ),
          Divider(),
          Row(
            children: [
              Column(
                children: [
                  Text('Open Task',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                  Text('04',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
              Spacer(),
              Column(
                children: [
                  Text('Projects',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                  Text('02',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
