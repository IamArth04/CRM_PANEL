import 'package:flutter/material.dart';

class NotitficationWidget extends StatelessWidget {
  const NotitficationWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Stack(
          children: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications)),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 20,
                height: 20,
                padding: const EdgeInsets.all(3.5),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Text(
                  "12",
                  style: TextStyle(
                      fontSize: 10,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          width: 20,
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.power_settings_new),
        ),
        const SizedBox(
          width: 20,
        ),
      ],
    );
  }
}
