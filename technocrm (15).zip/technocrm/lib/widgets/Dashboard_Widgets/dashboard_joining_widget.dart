import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class joiningandworkanniversarywidget extends StatelessWidget {
  const joiningandworkanniversarywidget({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> anniversaryDetails = [
      {
        "icon": "cake",
        "name": "Lorem Ipsum",
        "position": "Trainee",
        "department": "IT"
      },
      {
        "icon": "emoji",
        "name": "Lorem Ipsum",
        "position": "Senior",
        "department": "Marketing"
      },
    ];

    IconData getIcon(String iconName) {
      switch (iconName) {
        case 'cake':
          return Icons.cake_outlined;
        case 'emoji':
          return Icons.emoji_emotions_outlined;
        default:
          return Icons.help_outline;
      }
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Today's Joining & Work Anniversary",
            style: TextStyle(
              fontSize: 18,
              color: AppColors.titleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.fromLTRB(17, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Text(
                    "NO.",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    "Name",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    "Position",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    "Department",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          for (var i = 0; i < anniversaryDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
              child: Container(
                color: const Color.fromARGB(255, 222, 233, 241),
                padding: const EdgeInsets.all(8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Container(
                        alignment: Alignment.center,
                        child: Icon(
                          getIcon(anniversaryDetails[i]["icon"]!),
                          color: const Color.fromARGB(255, 5, 43, 85),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          anniversaryDetails[i]["name"]!,
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          anniversaryDetails[i]["position"]!,
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          anniversaryDetails[i]["department"]!,
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
