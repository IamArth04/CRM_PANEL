import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class NoticesWidget extends StatelessWidget {
  const NoticesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> notices = [
      {
        "date": "01 NOV",
        "notice": "Lorem ipsum dolor sit amet consectetur.",
      },
      {
        "date": "01 NOV",
        "notice":
            "Lorem ipsum dolor sit amet consectetur. Sed viverra varius mauris scelerisque. Proin laoreet aliquam sed rutrum non nisl.",
      },
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Notices",
            style: TextStyle(
              fontSize: 18,
              color: AppColors.titleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Column(
            children: notices.map((notice) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                            color: Colors.black,
                            width: 1.0,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              notice["date"]!.split(" ")[0],
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Divider(
                              color: Colors.black,
                              thickness: 1,
                              height: 10,
                            ),
                            Text(
                              notice["date"]!.split(" ")[1],
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          notice["notice"]!,
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
