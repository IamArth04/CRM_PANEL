import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/Inside_Widgets/dashboard_timelog_daybutton_widget.dart';

class WeekTimelogsWidget extends StatefulWidget {
  const WeekTimelogsWidget({super.key});

  @override
  _WeekTimelogsWidgetState createState() => _WeekTimelogsWidgetState();
}

class _WeekTimelogsWidgetState extends State<WeekTimelogsWidget> {
  String _selectedDay = "Th";

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Week Timelogs",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.titleColor,
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              const Text(
                "0 Absent This Week",
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF7D848D),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.fromLTRB(0, 0, 360, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var day in ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"])
                  DayButton(
                    day: day,
                    isSelected: _selectedDay == day,
                    onTap: () {
                      setState(() {
                        _selectedDay = day;
                      });
                    },
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Stack(
            children: [
              Container(
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              Container(
                height: 8,
                width: 580,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF072E73), Color(0xFF03A89E)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Duration : 0s",
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
              Text(
                "Break : 0s",
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
