import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class MyTaskWidget extends StatelessWidget {
  const MyTaskWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> taskDetails = [
      {
        "no": "01",
        "task": "Lorem ipsum dolor",
        "status": "Incomplete",
        "dueDate": "13-Dec-2023",
        "iconColor": Colors.red,
      },
      {
        "no": "02",
        "task": "Lorem ipsum dolor sit amet consectetur.",
        "status": "Incomplete",
        "dueDate": "--",
        "iconColor": Colors.red,
      },
      {
        "no": "03",
        "task": "Lorem ipsum dolor",
        "status": "Incomplete",
        "dueDate": "--",
        "iconColor": Colors.red,
      },
      {
        "no": "04",
        "task": "Lorem ipsum",
        "status": "Incomplete",
        "dueDate": "10-Nov-2023",
        "iconColor": Colors.red,
      },
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'My Task',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.titleColor,
            ),
          ),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Row(
              children: [
                SizedBox(
                  width: 40,
                  child: Text(
                    "No.",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Text(
                    "Task",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    "Status",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    "Due Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          for (var detail in taskDetails)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 0, 8),
              child: Container(
                padding: const EdgeInsets.all(8),
                color: const Color.fromARGB(255, 222, 233, 241),
                child: Row(
                  children: [
                    SizedBox(
                      width: 40,
                      child: Text(
                        detail["no"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(
                        detail["task"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.circle,
                            color: detail["iconColor"] as Color,
                            size: 14,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            detail["status"]!,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        detail["dueDate"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
