import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class NoticeDetailsWidget extends StatelessWidget {
  const NoticeDetailsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 0, 0, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Notice Details",
            style: TextStyle(
              fontSize: 20,
              color: AppColors.textColor,
            ),
          ),
          const Divider(
            color: Colors.grey,
          ),
          const SizedBox(height: 8.0),
          _buildTimeLogDetailRow(
              'Notice Heading',
              const Text(
                'Lorem ipsum dolor sit amet consectetur.',
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black,
                ),
              )),
          _buildTimeLogDetailRow(
              'Date',
              const Text(
                '07-11-2025',
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black,
                ),
              )),
          _buildTimeLogDetailRow(
              'To',
              const Text(
                'Employee',
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black,
                ),
              )),
          _buildTimeLogDetailRow(
              'Description',
              const Text(
                'Lorem ipsum dolor sit amet consectetur. Mi sagittis augue elit ultrices ultrices. Nulla felis suscipit faucibus dictum.',
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.black,
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildTimeLogDetailRow(String label, Widget value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 16.0,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: value,
          ),
        ],
      ),
    );
  }
}
