import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_bottombutton_widget.dart';

class ListNoticeBoardWidget extends StatefulWidget {
  const ListNoticeBoardWidget({super.key});

  @override
  State<ListNoticeBoardWidget> createState() => _ListNoticeBoardWidgetState();
}

class _ListNoticeBoardWidgetState extends State<ListNoticeBoardWidget> {
  List<Map<String, dynamic>> projectDetails = [
    {
      "CheckBox": false,
      "Notice": "Lorem ipsum dolor sit amet consectetur.",
      "Date": "07-11-2025",
      "To": "Employee",
      "Action": "View",
    },
  ];

  bool _selectAll = false;

  void _toggleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      for (var detail in projectDetails) {
        detail["CheckBox"] = _selectAll;
      }
    });
  }

  void _toggleCheckbox(int index, bool? value) {
    setState(() {
      projectDetails[index]["CheckBox"] = value ?? false;
      _selectAll = projectDetails.every((detail) => detail["CheckBox"] == true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(30, 10, 0, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(5, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Transform.scale(
                    scale: 0.7,
                    child: Checkbox(
                      value: _selectAll,
                      onChanged: _toggleSelectAll,
                      activeColor: Colors.grey,
                      checkColor: Colors.white,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const Expanded(
                  flex: 4,
                  child: Text(
                    "Notice",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 4,
                  child: Text(
                    "Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 4,
                  child: Text(
                    "To",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Action",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < projectDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(3, 10, 10, 0),
              child: Container(
                color: Colors.grey[200],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Transform.scale(
                        scale: 0.7,
                        child: Checkbox(
                          value: projectDetails[i]["CheckBox"],
                          onChanged: (value) => _toggleCheckbox(i, value),
                          activeColor: Colors.black87,
                          checkColor: Colors.white,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(
                        projectDetails[i]["Notice"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(
                        projectDetails[i]["Date"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(
                        projectDetails[i]["To"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert),
                        onSelected: (String value) {
                          if (value == 'View') {}
                        },
                        itemBuilder: (BuildContext context) {
                          return [
                            PopupMenuItem<String>(
                              value: 'View',
                              child: Center(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 20),
                                  decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'View',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ];
                        },
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        ),
                        color: Colors.white,
                        elevation: 4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(0, 0, 70, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Previous",
                        color: AppColors.bgColor),
                    const SizedBox(
                      width: 20,
                    ),
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Next",
                        color: AppColors.bgColor),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
