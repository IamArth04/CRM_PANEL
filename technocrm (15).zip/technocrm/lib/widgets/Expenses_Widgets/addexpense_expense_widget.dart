import 'package:flutter/material.dart';
import 'package:technocrm/widgets/Expenses_Widgets/model_expenses/inputfeild_expenses_model.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/models_task/task_inputfeild_work_model.dart';

class AddexpenseExpenseWidget extends StatelessWidget {
  const AddexpenseExpenseWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const InputfeildExpensesModel(
              labelText: 'Item Name*',
              hintText: '',
              contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            ),
            const SizedBox(width: 40),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.20,
              child: InputfeildExpensesModel(
                labelText: 'Cureency*',
                hintText: 'Rupee-(INR)',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(
                      value: 'Rupee-(INR)', child: Text('Rupee-(INR)')),
                  DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                  DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                  DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ),
            const SizedBox(width: 40),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.25,
              child: const InputfeildExpensesModel(
                labelText: 'Price*',
                hintText: 'e.g. 10000',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              ),
            ),
          ],
        ),
        const SizedBox(height: 25),
        Row(
          children: [
            const InputfeildExpensesModel(
              labelText: 'Purchase Date*',
              hintText: '',
              contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            ),
            const SizedBox(width: 40),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.20,
              child: InputfeildExpensesModel(
                labelText: 'Project*',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                  DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                  DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ),
            const SizedBox(width: 40),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.20,
              child: InputfeildExpensesModel(
                labelText: 'Expense Category*',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                  DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                  DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ),
          ],
        ),
        const SizedBox(height: 25),
        const InputfeildExpensesModel(
          labelText: 'Purchase From*',
          hintText: 'e.g. Indiamart',
          contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
        ),
        const SizedBox(
          height: 25,
        ),
        const Row(
          children: [
            Expanded(
              child: TaskInputfeildWorkModel(
                labelText: 'Description',
                hintText: '',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 100),
              ),
            )
          ],
        ),
        const SizedBox(
          height: 25,
        ),
        const Row(
          children: [
            Expanded(
              child: TaskInputfeildWorkModel(
                labelText: 'Bill',
                hintText: '',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 100),
              ),
            )
          ],
        )
      ],
    );
  }
}
