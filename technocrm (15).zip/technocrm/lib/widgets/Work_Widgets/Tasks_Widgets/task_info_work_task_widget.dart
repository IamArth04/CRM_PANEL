import 'package:flutter/material.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/models_task/task_inputfeild_work_model.dart';

class TaskInfoWorkTaskWidget extends StatelessWidget {
  const TaskInfoWorkTaskWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const TaskInputfeildWorkModel(
                labelText: 'Title*',
                hintText: '',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              ),
              const SizedBox(width: 40),
              TaskInputfeildWorkModel(
                labelText: 'Task Category',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                  DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                  DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.30,
            child: TaskInputfeildWorkModel(
              labelText: 'Project',
              hintText: '--',
              isDropdown: true,
              dropdownItems: const [
                DropdownMenuItem(value: '--', child: Text('--')),
                DropdownMenuItem(value: 'Half Day', child: Text('Half Day')),
                DropdownMenuItem(value: 'Full Day', child: Text('Full Day')),
                DropdownMenuItem(value: '2 Day', child: Text('2 Day')),
              ],
              onChanged: (value) {},
              contentPadding: const EdgeInsets.all(0),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const TaskInputfeildWorkModel(
                  labelText: 'Start Date*',
                  hintText: '12-01-2023',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 40),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const TaskInputfeildWorkModel(
                  labelText: 'Due Date*',
                  hintText: '13-01-2023',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 40),
              Container(
                padding: const EdgeInsets.fromLTRB(0, 23, 0, 0),
                child: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.check_box_outline_blank_outlined),
                  color: Colors.grey[400],
                  iconSize: 28,
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(0, 23, 60, 0),
                child: const Text(
                  "Without Due Date",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TaskInputfeildWorkModel(
                labelText: 'Assigned To',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(
                    value: '--',
                    child: Row(
                      children: [
                        Text('--'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 1',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar1.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Project Name'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 2',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar2.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 2'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 3',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar3.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 3'),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'Name 4',
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          backgroundImage: AssetImage('assets/avatar4.png'),
                        ),
                        SizedBox(width: 10),
                        Text('Name 4'),
                      ],
                    ),
                  ),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
              SizedBox(
                height: 50,
                width: 60,
                child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      border: Border.all(
                        color: Colors.grey,
                        width: 2,
                      ),
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(5.0),
                        bottomRight: Radius.circular(5.0),
                      ),
                    ),
                    child: const CircleAvatar(
                      radius: 15,
                      backgroundImage: AssetImage('assets/client.png'),
                    )),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          const Row(
            children: [
              Expanded(
                child: TaskInputfeildWorkModel(
                  labelText: 'Description',
                  hintText: '',
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 80),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
