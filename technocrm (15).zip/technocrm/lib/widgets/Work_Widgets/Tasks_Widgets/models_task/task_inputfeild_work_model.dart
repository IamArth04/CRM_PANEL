import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class TaskInputfeildWorkModel extends StatelessWidget {
  final String labelText;
  final String hintText;
  final bool isDropdown;
  final List<DropdownMenuItem<String>>? dropdownItems;
  final TextInputType keyboardType;
  final Function(String?)? onChanged;
  final EdgeInsetsGeometry contentPadding;

  const TaskInputfeildWorkModel({
    super.key,
    required this.labelText,
    required this.hintText,
    required this.contentPadding,
    this.isDropdown = false,
    this.dropdownItems,
    this.keyboardType = TextInputType.text,
    this.onChanged,
    //this.contentPadding = const EdgeInsets.fromLTRB(10, 0, 0, 30),
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.40,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            labelText,
            style: TextStyle(
              fontSize: 18,
              color: AppColors.titleColor,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 5),
          if (isDropdown && dropdownItems != null)
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                hintText: hintText,
                contentPadding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                hintStyle: const TextStyle(
                  color: Colors.black,
                ),
              ),
              items: dropdownItems,
              onChanged: onChanged,
            )
          else
            TextFormField(
              decoration: InputDecoration(
                hintText: hintText,
                contentPadding: contentPadding,
                hintStyle: const TextStyle(
                  color: Colors.black,
                ),
                border: const OutlineInputBorder(),
              ),
              keyboardType: keyboardType,
            ),
        ],
      ),
    );
  }
}
