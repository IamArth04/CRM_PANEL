import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/Info_tasks_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/drawer_task_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/task_info_work_task_widget.dart';

class HomeTaskWorkScreen extends StatefulWidget {
  const HomeTaskWorkScreen({super.key});

  @override
  State<HomeTaskWorkScreen> createState() => _HomeTaskWorkScreenState();
}

class _HomeTaskWorkScreenState extends State<HomeTaskWorkScreen> {
  void _onNewTaskTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Add Task",
            style: TextStyle(
              fontSize: 26,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  "Task Info",
                  style: TextStyle(
                    fontSize: 22,
                    color: AppColors.titleColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                const TaskInfoWorkTaskWidget(),
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(titleText: "Task", subtitleText: "Task"),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const DrawerTaskWorkWidget(),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 0, 10, 0),
              child: Row(
                children: [
                  ButtonleadWidget(
                    title: "Add Task",
                    icon: Icons.add,
                    color: Colors.blue,
                    Tcolor: Colors.white,
                    function: () {
                      _onNewTaskTap(context);
                    },
                  ),
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {},
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const InfoTasksWorkWidget(),
          ],
        ),
      ),
    );
  }
}
