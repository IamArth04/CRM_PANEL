import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_bottombutton_widget.dart';

class InfoTasksWorkWidget extends StatefulWidget {
  const InfoTasksWorkWidget({super.key});

  @override
  _InfoTasksWorkWidgetState createState() => _InfoTasksWorkWidgetState();
}

class _InfoTasksWorkWidgetState extends State<InfoTasksWorkWidget> {
  List<Map<String, dynamic>> projectDetails = [
    {
      "CheckBox": false,
      "Id": 43,
      "Code": "ABC - 848",
      "Task": "Title",
      "Task Description": "Description",
      "StartDate": "01-07-2023",
      "Due Date": "30-09-2023",
      "Completed On": "30-09-2023",
      "Assigned To": "Name",
      "ClientImage": "client.png",
      "Status": "In Progress",
      "Action": "View",
    },
    {
      "CheckBox": false,
      "Id": 43,
      "Code": "ABC - 848",
      "Task": "Title",
      "Task Description": "Description",
      "StartDate": "01-07-2023",
      "Due Date": "30-09-2023",
      "Completed On": "30-09-2023",
      "Assigned To": "Name",
      "ClientImage": "client.png",
      "Status": "Not Started",
      "Action": "View",
    },
    {
      "CheckBox": false,
      "Id": 43,
      "Code": "ABC - 848",
      "Task": "Title",
      "Task Description": "Description",
      "StartDate": "01-07-2023",
      "Due Date": "30-09-2023",
      "Completed On": "30-09-2023",
      "Assigned To": "Name",
      "ClientImage": "client.png",
      "Status": "Completed",
      "Action": "View",
    },
  ];

  bool _selectAll = false;

  void _toggleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      for (var detail in projectDetails) {
        detail["CheckBox"] = _selectAll;
      }
    });
  }

  void _toggleCheckbox(int index, bool? value) {
    setState(() {
      projectDetails[index]["CheckBox"] = value ?? false;
      _selectAll = projectDetails.every((detail) => detail["CheckBox"] == true);
    });
  }

  void _updateStatus(int index, String newStatus) {
    setState(() {
      projectDetails[index]["Status"] = newStatus;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(7, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Transform.scale(
                    scale: 0.7,
                    child: Checkbox(
                      value: _selectAll,
                      onChanged: _toggleSelectAll,
                      activeColor: Colors.grey,
                      checkColor: Colors.white,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Id",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Code",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Task",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Start Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Due Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Completed On",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Assigned To",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Status",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Action",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < projectDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 5, 0),
              child: Container(
                margin: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Transform.scale(
                        scale: 0.7,
                        child: Checkbox(
                          value: projectDetails[i]["CheckBox"],
                          onChanged: (value) => _toggleCheckbox(i, value),
                          activeColor: Colors.black87,
                          checkColor: Colors.white,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        projectDetails[i]["Id"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Code"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            projectDetails[i]["Task"]!,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            projectDetails[i]["Task Description"]!,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["StartDate"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Due Date"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Completed On"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage:
                                AssetImage(projectDetails[i]["ClientImage"]!),
                            radius: 10,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            projectDetails[i]["Assigned To"]!,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 4.0),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: _getStatusColor(
                                    projectDetails[i]["Status"]!),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: projectDetails[i]["Status"]!,
                                  icon: const Icon(Icons.arrow_drop_down),
                                  iconSize: 24,
                                  elevation: 16,
                                  style: const TextStyle(color: Colors.black),
                                  onChanged: (String? newValue) {
                                    _updateStatus(i, newValue!);
                                  },
                                  items: <String>[
                                    '--',
                                    'In Progress',
                                    'Completed',
                                    'Not Started'
                                  ].map<DropdownMenuItem<String>>(
                                      (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: IconButton(
                        icon: const Icon(Icons.more_vert),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(0, 0, 50, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Previous",
                        color: AppColors.bgColor),
                    const SizedBox(
                      width: 20,
                    ),
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Next",
                        color: AppColors.bgColor),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}

Color _getStatusColor(String status) {
  switch (status) {
    case "Completed":
      return Colors.green;
    case "In Progress":
      return Colors.blue;
    case "Not Started":
      return Colors.red[700]!;
    default:
      return Colors.black;
  }
}
