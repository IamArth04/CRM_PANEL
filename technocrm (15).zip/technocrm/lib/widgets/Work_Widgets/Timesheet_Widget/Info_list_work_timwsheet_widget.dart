import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_bottombutton_widget.dart';
//import 'package:technocrm/Models/Repository.dart' as user_repo;

class InfoListWorkTimwsheetWidget extends StatefulWidget {
  const InfoListWorkTimwsheetWidget({super.key});

  @override
  _InfoListWorkTimwsheetWidgetState createState() =>
      _InfoListWorkTimwsheetWidgetState();
}

class _InfoListWorkTimwsheetWidgetState
    extends State<InfoListWorkTimwsheetWidget> {
  List<Map<String, dynamic>> projectDetails = [
    {
      "CheckBox": false,
      "Id": 43,
      "Code": "CODE-01",
      "Task": "Title",
      "Task Description": "Description",
      "Client": "Client Name",
      "ClientImage": "client.png",
      "CompanyName": "Company Name",
      "StartDate": "30-09-2023  02:42 pm",
      "Deadline": "10-10-2023  02:42 pm",
      "Total Hours": "19h 24m",
      "Action": "View",
    },
  ];

  bool _selectAll = false;

  void _toggleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      for (var detail in projectDetails) {
        detail["CheckBox"] = _selectAll;
      }
    });
  }

  void _toggleCheckbox(int index, bool? value) {
    setState(() {
      projectDetails[index]["CheckBox"] = value ?? false;
      _selectAll = projectDetails.every((detail) => detail["CheckBox"] == true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 5, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Transform.scale(
                    scale: 0.7,
                    child: Checkbox(
                      value: _selectAll,
                      onChanged: _toggleSelectAll,
                      activeColor: Colors.grey,
                      checkColor: Colors.white,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Id",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Code",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Task",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Client",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Start Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Deadline",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Total Hours",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Action",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < projectDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(3, 10, 10, 0),
              child: Container(
                margin: const EdgeInsets.fromLTRB(20, 0, 10, 0),
                //padding: const EdgeInsets.fromLTRB(7, 0, 0, 0),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Transform.scale(
                        scale: 0.7,
                        child: Checkbox(
                          value: projectDetails[i]["CheckBox"],
                          onChanged: (value) => _toggleCheckbox(i, value),
                          activeColor: Colors.black87,
                          checkColor: Colors.white,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        projectDetails[i]["Id"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        projectDetails[i]["Code"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            projectDetails[i]["Task"]!,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            projectDetails[i]["Task Description"]!,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage:
                                AssetImage(projectDetails[i]["ClientImage"]!),
                            radius: 10,
                          ),
                          const SizedBox(width: 5),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                projectDetails[i]["Client"]!,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                projectDetails[i]["CompanyName"]!,
                                style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        projectDetails[i]["StartDate"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        projectDetails[i]["Deadline"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Total Hours"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert),
                        onSelected: (String value) {
                          if (value == 'View') {}
                        },
                        itemBuilder: (BuildContext context) {
                          return [
                            PopupMenuItem<String>(
                              value: 'View',
                              child: Center(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 20),
                                  decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'View',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ];
                        },
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        ),
                        color: Colors.white,
                        elevation: 4,
                      ),
                    ),
                    // Expanded(
                    //   flex: 1,
                    //   child: IconButton(
                    //     icon: const Icon(Icons.more_vert),
                    //     onPressed: () {
                    //       //user_repo.localDB.value.isProjectName = true;
                    //     },
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Previous",
                        color: AppColors.bgColor),
                    const SizedBox(
                      width: 20,
                    ),
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Next",
                        color: AppColors.bgColor),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
