import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class HistoryTimesheetWorkWidget extends StatelessWidget {
  const HistoryTimesheetWorkWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "History",
            style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: AppColors.titleColor),
          ),
          const Divider(
            color: Colors.black,
          ),
          const SizedBox(height: 8.0),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Column(
              children: [
                _buildInfoRow(
                  icon: Icons.access_time,
                  label: "Start Time",
                  value: "10-10-2023  02:42 PM",
                ),
                _buildDivider(),
                _buildInfoRow(
                  icon: Icons.access_time,
                  label: "End Time",
                  value: "10-10-2023  02:42 PM",
                ),
                _buildDivider(),
                _buildInfoRow(
                  icon: Icons.access_time,
                  label: "Total Hours",
                  value: "10-10-2023  02:42 PM",
                ),
                _buildDivider(),
                _buildInfoRow(
                  icon: Icons.work_outline,
                  label: "Task",
                  value: "Task Title",
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Icon(icon, size: 20.0, color: Colors.grey),
                const SizedBox(width: 8.0),
                Text(
                  label,
                  style: const TextStyle(fontSize: 16.0, color: Colors.black54),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              value,
              style: const TextStyle(fontSize: 16.0, color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return const Divider(
      color: Colors.grey,
      height: 1.0,
      thickness: 1.0,
    );
  }
}
