import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Timesheet_Widget/Info_list_work_timwsheet_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Timesheet_Widget/history_timesheet_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Timesheet_Widget/time_log_work_timesheet_widget.dart';

class HomeTimesheetWorkScreen extends StatefulWidget {
  const HomeTimesheetWorkScreen({super.key});

  @override
  State<HomeTimesheetWorkScreen> createState() =>
      _HomeTimesheetWorkScreenState();
}

class _HomeTimesheetWorkScreenState extends State<HomeTimesheetWorkScreen> {
  void _onNewTimesheetTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Timesheet",
            style: TextStyle(
              fontSize: 26,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: TimeLogWorkTimesheetWidget(),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(child: HistoryTimesheetWorkWidget()),
                  ],
                )
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(
                    titleText: "Timesheet", subtitleText: "Timesheet"),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const LeadsHeadtitleWidget(),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(27, 0, 10, 0),
              child: Row(
                children: [
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {
                      _onNewTimesheetTap(context);
                    },
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const InfoListWorkTimwsheetWidget(),
          ],
        ),
      ),
    );
  }
}
