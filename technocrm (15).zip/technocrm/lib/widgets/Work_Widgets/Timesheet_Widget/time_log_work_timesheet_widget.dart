import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class TimeLogWorkTimesheetWidget extends StatelessWidget {
  const TimeLogWorkTimesheetWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Time Log Details',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppColors.titleColor,
            ),
          ),
          const Divider(color: Colors.black),
          const SizedBox(height: 8.0),
          _buildTimeLogDetailRow(
              'Start Time', const Text('10-10-2023  02:42 Pm')),
          _buildTimeLogDetailRow(
              'End Time', const Text('10-10-2023  02:42 Pm')),
          _buildTimeLogDetailRow(
              'Total Hours', const Text('10-10-2023  02:42 Pm')),
          _buildTimeLogDetailRow('Memo', const Text('Task Code')),
          _buildTimeLogDetailRow('Project', const Text('Project Name')),
          _buildTimeLogDetailRow('Task', const Text('Task Title')),
          _buildTimeLogDetailRow('Employee', _buildEmployeeDetails()),
        ],
      ),
    );
  }

  Widget _buildTimeLogDetailRow(String label, Widget value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 16.0,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: value,
          ),
        ],
      ),
    );
  }

  Widget _buildEmployeeDetails() {
    return Row(
      children: [
        const CircleAvatar(
          radius: 16,
          backgroundImage: AssetImage('assets/client.png'),
        ),
        const SizedBox(width: 8.0),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Client Name',
              style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
              ),
            ),
            Text(
              'Developer',
              style: TextStyle(
                fontSize: 10.0,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(10, 0, 0, 10),
          child: const Text(
            "It's You",
            style: TextStyle(
              fontSize: 12.0,
              color: Colors.black,
            ),
          ),
        ),
      ],
    );
  }
}
