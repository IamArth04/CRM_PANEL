import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_bottombutton_widget.dart';
import 'package:technocrm/Models/Repository.dart' as user_repo;

class InfoProjectWorkWidget extends StatefulWidget {
  const InfoProjectWorkWidget({super.key});

  @override
  _InfoProjectWorkWidgetState createState() => _InfoProjectWorkWidgetState();
}

class _InfoProjectWorkWidgetState extends State<InfoProjectWorkWidget> {
  List<Map<String, dynamic>> projectDetails = [
    {
      "CheckBox": false,
      "Id": 43,
      "ProjectName": "Project Name",
      "Members": ["u1.png", "u2.png", "u3.png", "u4.png"],
      "StartDate": "01-07-2023",
      "Deadline": "30-09-2023",
      "Client": "Client Name",
      "ClientImage": "client.png",
      "CompanyName": "Company Name",
      "Progress": 75,
      "Status": "In Progress",
      "Action": "View",
    },
    {
      "CheckBox": false,
      "Id": 43,
      "ProjectName": "Project Name",
      "Members": ["u1.png", "u2.png", "u3.png", "u4.png"],
      "StartDate": "01-07-2023",
      "Deadline": "30-09-2023",
      "Client": "Client Name",
      "ClientImage": "client.png",
      "CompanyName": "Company Name",
      "Progress": 0,
      "Status": "Not Started",
      "Action": "View",
    },
    {
      "CheckBox": false,
      "Id": 43,
      "ProjectName": "Project Name",
      "Members": ["u1.png", "u2.png", "u3.png", "u4.png"],
      "StartDate": "01-07-2023",
      "Deadline": "30-09-2023",
      "Client": "Client Name",
      "ClientImage": "client.png",
      "CompanyName": "Company Name",
      "Progress": 100,
      "Status": "Completed",
      "Action": "View",
    },
    {
      "CheckBox": false,
      "Id": 43,
      "ProjectName": "Project Name",
      "Members": ["u1.png", "u2.png", "u3.png", "u4.png"],
      "StartDate": "01-07-2023",
      "Deadline": "30-09-2023",
      "Client": "Client Name",
      "ClientImage": "client.png",
      "CompanyName": "Company Name",
      "Progress": 75,
      "Status": "In Progress",
      "Action": "View",
    },
  ];

  bool _selectAll = false;

  void _toggleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      for (var detail in projectDetails) {
        detail["CheckBox"] = _selectAll;
      }
    });
  }

  void _toggleCheckbox(int index, bool? value) {
    setState(() {
      projectDetails[index]["CheckBox"] = value ?? false;
      _selectAll = projectDetails.every((detail) => detail["CheckBox"] == true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(30, 10, 10, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(5, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Transform.scale(
                    scale: 0.7,
                    child: Checkbox(
                      value: _selectAll,
                      onChanged: _toggleSelectAll,
                      activeColor: Colors.grey,
                      checkColor: Colors.white,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Id",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Project Name",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Members",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Start Date",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: Text(
                    "Deadline",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Client",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Progress",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 3,
                  child: Text(
                    "Status",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Expanded(
                  flex: 1,
                  child: Text(
                    "Action",
                    style: TextStyle(color: Colors.grey),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < projectDetails.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 10, 10, 0),
              child: Container(
                margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Transform.scale(
                        scale: 0.7,
                        child: Checkbox(
                          value: projectDetails[i]["CheckBox"],
                          onChanged: (value) => _toggleCheckbox(i, value),
                          activeColor: Colors.black87,
                          checkColor: Colors.white,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        projectDetails[i]["Id"].toString(),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["ProjectName"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          for (var member in projectDetails[i]["Members"])
                            CircleAvatar(
                              backgroundImage: AssetImage(member),
                              radius: 10,
                            ),
                          const Text("+4", style: TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["StartDate"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        projectDetails[i]["Deadline"]!,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage:
                                AssetImage(projectDetails[i]["ClientImage"]!),
                            radius: 10,
                          ),
                          const SizedBox(width: 5),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                projectDetails[i]["Client"]!,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                projectDetails[i]["CompanyName"]!,
                                style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Stack(
                        alignment: Alignment.centerLeft,
                        children: [
                          Container(
                            height: 20,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.blueGrey[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          FractionallySizedBox(
                            widthFactor: projectDetails[i]["Progress"] / 100,
                            child: Container(
                              height: 20,
                              decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: Center(
                              child: Text(
                                "${projectDetails[i]["Progress"]}%",
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Align(
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: _getStatusColor(
                                    projectDetails[i]["Status"]),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              projectDetails[i]["Status"]!,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 14,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: IconButton(
                        icon: const Icon(Icons.more_vert),
                        onPressed: () {
                          user_repo.localDB.value.isProjectName = true;
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(0, 0, 50, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Previous",
                        color: AppColors.bgColor),
                    const SizedBox(
                      width: 20,
                    ),
                    BottomLeadbuttonWidget(
                        function: () {},
                        title: "Next",
                        color: AppColors.bgColor),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}

Color _getStatusColor(String status) {
  switch (status) {
    case "Completed":
      return Colors.green;
    case "In Progress":
      return Colors.blue;
    case "Not Started":
      return Colors.grey[700]!;
    default:
      return Colors.black;
  }
}
