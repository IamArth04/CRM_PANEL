import 'package:flutter/material.dart';

class MemberProjectWorkWidget extends StatelessWidget {
  const MemberProjectWorkWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> members = List.generate(12, (index) {
      return {
        "name": "Harsh Verma",
        "role": "Developer",
        "email": "jane@microsoft.com",
        "avatar": "assets/avatar${index + 1}.png",
      };
    });

    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 20, 0),
      padding: const EdgeInsets.fromLTRB(20, 0, 0, 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Members",
            style: TextStyle(
              fontSize: 18,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 16.0),
          Table(
            columnWidths: const {
              0: FixedColumnWidth(80),
              1: FlexColumnWidth(140),
              2: FlexColumnWidth(80),
              3: FlexColumnWidth(140),
            },
            children: [
              const TableRow(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      "#",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      "Name",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      "Role",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      "Email",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ],
              ),
              // Member Rows
              ...members.asMap().entries.map((entry) {
                int index = entry.key + 1;
                Map<String, String> member = entry.value;

                return TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        index.toString().padLeft(2, '0'),
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2.0),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage(member['avatar']!),
                            radius: 15,
                          ),
                          const SizedBox(width: 8.0),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                member['name']!,
                                style: const TextStyle(fontSize: 14),
                              ),
                              const Text(
                                "UI/UX",
                                style:
                                    TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        member['role']!,
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Text(
                        member['email']!,
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                  ],
                );
              }),
            ],
          ),
        ],
      ),
    );
  }
}
