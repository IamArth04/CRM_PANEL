import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/client_project_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/member_project_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/models_projects/project_progress_model.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/progress_work_project_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/projectprogress_project_work_widget.dart';
import 'package:technocrm/Models/Repository.dart' as user_repo;

class ProjectNameWorkWidget extends StatefulWidget {
  const ProjectNameWorkWidget({super.key});

  @override
  State<ProjectNameWorkWidget> createState() =>
      _ProjectProgressWorkWidgetState();
}

class _ProjectProgressWorkWidgetState extends State<ProjectNameWorkWidget> {
  @override
  void dispose() {
    user_repo.localDB.value.isProjectName = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: const SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ProjectProgressModel(
                    titleText: "Project Name",
                    subtitleText: "Projects",
                    subtitleText1: "Project Name"),
                NotitficationWidget(),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 0)),
                Text(
                  "Overview",
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(child: ProjectprogressProjectWorkWidget()),
                SizedBox(width: 20),
                Expanded(child: ClientProjectWorkWidget()),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: ProgressWorkProjectWidget()),
                SizedBox(width: 20),
                Expanded(child: MemberProjectWorkWidget()),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
