import 'package:flutter/material.dart';

class ProgressWorkProjectWidget extends StatelessWidget {
  final double size;
  final double segmentWidth;
  final double borderRadius;

  const ProgressWorkProjectWidget({
    super.key,
    this.size = 200,
    this.segmentWidth = 35,
    this.borderRadius = 20,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 0, 40, 0),
      margin: const EdgeInsets.fromLTRB(40, 0, 20, 80),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Project Progress",
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
            ),
          ),
          const SizedBox(
            height: 40,
          ),
          Stack(
            children: [
              Center(
                child: Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: CustomPaint(
                    painter: CircularSegmentedPainter(
                      segments: [
                        Segment(
                            color: Colors.blue,
                            startAngle: -20,
                            sweepAngle: 80),
                        Segment(
                            color: Colors.green,
                            startAngle: 70,
                            sweepAngle: 80),
                        Segment(
                            color: Colors.red, startAngle: 160, sweepAngle: 80),
                        Segment(
                            color: Colors.yellow,
                            startAngle: 250,
                            sweepAngle: 80),
                      ],
                      segmentWidth: segmentWidth,
                      borderRadius: borderRadius,
                    ),
                  ),
                ),
              ),
              const Positioned(
                top: 0,
                left: 80,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '30%',
                      style: TextStyle(
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Incomplete',
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
              ),
              const Positioned(
                top: 0,
                right: 80,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '25%',
                      style: TextStyle(
                          color: Colors.yellow,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'To Do',
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
              ),
              const Positioned(
                bottom: 0,
                right: 80,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '20%',
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Doing',
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
              ),
              const Positioned(
                bottom: 0,
                left: 80,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '10%',
                      style: TextStyle(
                          color: Colors.green,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Completed',
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class Segment {
  final Color color;
  final double startAngle;
  final double sweepAngle;

  Segment({
    required this.color,
    required this.startAngle,
    required this.sweepAngle,
  });
}

class CircularSegmentedPainter extends CustomPainter {
  final List<Segment> segments;
  final double segmentWidth;
  final double borderRadius;

  CircularSegmentedPainter({
    required this.segments,
    required this.segmentWidth,
    required this.borderRadius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = segmentWidth
      ..strokeCap = StrokeCap.butt;

    final radius = size.width / 2 - segmentWidth / 2;
    final center = Offset(size.width / 2, size.height / 2);

    for (final segment in segments) {
      paint.color = segment.color;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        _degreesToRadians(segment.startAngle),
        _degreesToRadians(segment.sweepAngle),
        false,
        paint,
      );
    }
  }

  double _degreesToRadians(double degrees) {
    return degrees * (3.141592653589793238 / 180);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
