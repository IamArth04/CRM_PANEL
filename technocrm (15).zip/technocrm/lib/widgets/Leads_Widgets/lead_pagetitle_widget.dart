import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class LeadsPagetitleWidget extends StatelessWidget {
  final String titleText, subtitleText;

  const LeadsPagetitleWidget(
      {super.key, required this.titleText, required this.subtitleText});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(40, 0, 20, 0),
          child: Text(
            titleText,
            style: TextStyle(
              fontSize: 25,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Row(
          children: [
            const Text(
              "Home",
              style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            const Icon(
              Icons.circle,
              color: Colors.grey,
              size: 8,
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              subtitleText,
              style: const TextStyle(
                fontSize: 15,
                color: Colors.grey,
              ),
            ),
          ],
        )
      ],
    );
  }
}
