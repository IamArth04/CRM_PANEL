import 'package:flutter/material.dart';

class BottomLeadbuttonWidget extends StatelessWidget {
  final Function function;
  final String title;
  //final IconData icon;
  final Color color;
  const BottomLeadbuttonWidget(
      {super.key,
      required this.function,
      required this.title,
      //required this.icon,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        function();
      },
      child: Container(
        decoration: BoxDecoration(
          color: color,
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          child: Row(
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
