import 'package:flutter/material.dart';

class ButtonleadWidget extends StatelessWidget {
  final Function function;
  final String title;
  final IconData icon;
  final Color color;
  final Color Tcolor;
  const ButtonleadWidget(
      {super.key,
      required this.function,
      required this.title,
      required this.icon,
      required this.color,
      required this.Tcolor});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        function();
      },
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Icon(
                icon,
                color: Tcolor,
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                title,
                style: TextStyle(color: Tcolor, fontSize: 14),
              ),
              const SizedBox(
                width: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
