import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';

class AddleadHeadtitleWidget extends StatelessWidget {
  const AddleadHeadtitleWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Add Lead Info',
            style: TextStyle(
              fontSize: 26,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            width: 15,
          ),
          const Row(
            //crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "Home",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
              SizedBox(
                width: 5,
              ),
              Icon(
                Icons.circle,
                color: Colors.grey,
                size: 8,
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                "Leads",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
              SizedBox(
                width: 5,
              ),
              Icon(
                Icons.circle,
                color: Colors.grey,
                size: 8,
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                "Add Lead Info",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
