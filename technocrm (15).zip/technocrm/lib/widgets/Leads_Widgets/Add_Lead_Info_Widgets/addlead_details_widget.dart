import 'package:flutter/material.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_inputfeild_widget.dart';

class LeadDetailsWidget extends StatelessWidget {
  const LeadDetailsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 120, 140),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              InputFieldWidget(
                labelText: 'Salutations',
                hintText: '--',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(value: 'Mr.', child: Text('Mr.')),
                  DropdownMenuItem(value: 'Ms.', child: Text('Ms.')),
                  DropdownMenuItem(value: 'Mrs.', child: Text('Mrs.')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
              const SizedBox(width: 20),
              const InputFieldWidget(
                labelText: 'Lead Name *',
                hintText: 'e.g. John Doe',
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              ),
              const SizedBox(width: 20),
              const InputFieldWidget(
                labelText: 'Lead Email',
                hintText: 'e.g. johndoe@example.com',
                keyboardType: TextInputType.emailAddress,
                contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
              ),
            ],
          ),
          const SizedBox(height: 40),
          Row(
            children: [
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.06,
                    child: InputFieldWidget(
                      labelText: 'Lead Value',
                      hintText: 'INR',
                      isDropdown: true,
                      dropdownItems: const [
                        DropdownMenuItem(
                          value: '--',
                          child: Row(
                            children: [
                              Text('--'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Mrs',
                          child: Row(
                            children: [
                              Text('Mrs'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Dr',
                          child: Row(
                            children: [
                              Text('Dr'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (value) {},
                      contentPadding: const EdgeInsets.all(0),
                    ),
                  ),
                  const SizedBox(
                    width: 4,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.19,
                    child: const InputFieldWidget(
                      labelText: '',
                      hintText: '0',
                      contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 30),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 20),
              InputFieldWidget(
                labelText: 'Allow Follow Up',
                hintText: 'Yes',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: 'Yes', child: Text('Yes')),
                  DropdownMenuItem(value: 'No', child: Text('No')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
              const SizedBox(width: 20),
              InputFieldWidget(
                labelText: 'Status',
                hintText: 'Warm',
                isDropdown: true,
                dropdownItems: const [
                  DropdownMenuItem(value: '--', child: Text('--')),
                  DropdownMenuItem(
                      value: 'inprocess', child: Text('In Process')),
                  DropdownMenuItem(
                      value: 'converted', child: Text('Converted')),
                  DropdownMenuItem(value: 'Cold', child: Text('Cold')),
                  DropdownMenuItem(value: 'Hot', child: Text('Hot')),
                  DropdownMenuItem(value: 'Lost', child: Text('Lost')),
                  DropdownMenuItem(value: 'Warm', child: Text('Warm')),
                ],
                onChanged: (value) {},
                contentPadding: const EdgeInsets.all(0),
              ),
            ],
          ),
          const SizedBox(height: 40),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.25,
                child: InputFieldWidget(
                  labelText: 'Products',
                  hintText: 'Select Product',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(
                        value: 'Product1', child: Text('Select Product')),
                    DropdownMenuItem(
                        value: 'Product2', child: Text('Product 2')),
                    DropdownMenuItem(
                        value: 'Product3', child: Text('Product 3')),
                    DropdownMenuItem(
                        value: 'Product4', child: Text('Product 4')),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
