import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_inputfeild_widget.dart';

class LeadContactDetailsWidget extends StatelessWidget {
  const LeadContactDetailsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 50, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.keyboard_arrow_up_outlined,
                color: AppColors.titleColor,
                size: 30,
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                "Company details",
                style: TextStyle(
                  fontSize: 20,
                  color: AppColors.titleColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'Company Name',
                  hintText: 'e.g.Acme Corporation',
                  keyboardType: TextInputType.name,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'Website',
                  hintText: 'e.g. https://www.example.com',
                  keyboardType: TextInputType.url,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'Mobile',
                  hintText: 'e.g. 1234567890',
                  keyboardType: TextInputType.number,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'Office Phone Number',
                  hintText: '',
                  keyboardType: TextInputType.number,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              )
            ],
          ),
          const SizedBox(height: 40),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: InputFieldWidget(
                  labelText: 'Country',
                  hintText: '--',
                  isDropdown: true,
                  dropdownItems: const [
                    DropdownMenuItem(value: '--', child: Text('--')),
                    DropdownMenuItem(value: 'india', child: Text('India')),
                    DropdownMenuItem(value: 'usa', child: Text('USA')),
                    DropdownMenuItem(value: 'canada', child: Text('Canada')),
                    DropdownMenuItem(value: 'france', child: Text('France')),
                  ],
                  onChanged: (value) {},
                  contentPadding: const EdgeInsets.all(0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'State',
                  hintText: 'e.g. California',
                  keyboardType: TextInputType.text,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'State',
                  hintText: 'e.g. New York',
                  keyboardType: TextInputType.text,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              ),
              const SizedBox(width: 20),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.20,
                child: const InputFieldWidget(
                  labelText: 'Postal Code',
                  hintText: 'e.g. 30030',
                  keyboardType: TextInputType.number,
                  contentPadding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                ),
              )
            ],
          ),
          const SizedBox(height: 40),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.85,
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: InputFieldWidget(
                    labelText: 'Address',
                    hintText: 'e.g. 132, My Street, Kingston, New York 124401',
                    keyboardType: TextInputType.text,
                    contentPadding: EdgeInsets.fromLTRB(10, 5, 0, 100),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
