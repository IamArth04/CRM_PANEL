import 'package:flutter/material.dart';
import 'package:technocrm/Models/navigation_model.dart';
import 'package:technocrm/controller/navigation_controller.dart';
import 'package:technocrm/widgets/HR_Widgets/Navigation/navigation_HR_widget.dart';
import 'package:technocrm/Models/Repository.dart' as user_repo;

class Navigation extends StatefulWidget {
  final int currentIndex;
  final Function(int) onTabTapped;

  const Navigation({
    super.key,
    required this.currentIndex,
    required this.onTabTapped,
  });

  @override
  _NavigationState createState() => _NavigationState();
}

class _NavigationState extends State<Navigation> with TickerProviderStateMixin {
  late List<NavigationController> _controllers;
  bool isHrExpanded = false;
  bool isLeave = false,
      isAttendence = false,
      isHoliday = false,
      isAppri = false;
  bool isWorkExpanded = false;
  bool isProjects = false, isTasks = false, isTimesheet = false;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(11, (index) => NavigationController(this));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.13,
      height: double.infinity,
      color: Colors.white,
      padding: const EdgeInsets.all(6.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: _buildNavigationItems(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.only(bottom: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                child: FittedBox(
                  fit: BoxFit.contain,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'TECHNO PARTICLES',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 1, 0, 51)),
                      ),
                      Text(
                        'PRIVATE LIMITED',
                        style: TextStyle(
                          fontSize: 10,
                          color: Color.fromARGB(255, 2, 119, 82),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ConstrainedBox(
                constraints: const BoxConstraints(
                  maxHeight: 60,
                  maxWidth: 60,
                ),
                child: Image.asset('assets/logo.png', fit: BoxFit.cover),
              ),
            ],
          ),
          Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: Colors.grey.shade400,
                    child: const CircleAvatar(
                      radius: 17,
                      backgroundImage: AssetImage('assets/user.png'),
                    ),
                  ),
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Harsh',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'UI/UX Designer',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildNavigationItems() {
    final List<Map<String, dynamic>> items = [
      {'icon': Icons.dashboard_outlined, 'text': 'Dashboard'},
      {'icon': Icons.person_3_outlined, 'text': 'Leads'},
      {'icon': Icons.people_outline, 'text': 'HR'},
      {'icon': Icons.work_outline, 'text': 'Work'},
      {'icon': Icons.attach_money_rounded, 'text': 'Expenses'},
      {'icon': Icons.headset_mic_outlined, 'text': 'Tickets'},
      {'icon': Icons.event_outlined, 'text': 'Events'},
      {'icon': Icons.mark_as_unread_outlined, 'text': 'Messages'},
      {'icon': Icons.bookmark_add_outlined, 'text': 'Notice Board'},
      {'icon': Icons.my_library_books_outlined, 'text': 'Knowledge Base'},
      {'icon': Icons.settings_outlined, 'text': 'Settings'},
    ];

    return items.asMap().entries.map((entry) {
      int idx = entry.key;
      Map<String, dynamic> item = entry.value;

      if (item['text'] == 'HR') {
        return _buildHRSection(idx);
      }

      if (item['text'] == 'Work') {
        return _buildWorkSection(idx);
      }

      return NavigationItem(
        icon: item['icon'],
        text: item['text'],
        isExpandable: false,
        onTap: () => widget.onTabTapped(idx),
        isSelected: idx == widget.currentIndex,
        controller: _controllers[idx],
      );
    }).toList();
  }

  Widget _buildHRSection(int idx) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: NavigationItem(
                icon: Icons.people_outline,
                text: 'HR',
                isExpandable: true,
                onTap: () {
                  widget.onTabTapped(idx);
                  setState(() {
                    user_repo.localDB.value.isLeave = true;
                    user_repo.localDB.value.isAttendance = false;
                    user_repo.localDB.value.isHoliday = false;
                    user_repo.localDB.value.isAppreciation = false;
                    isLeave = !isHrExpanded;
                    isAppri = false;
                    isAttendence = false;
                    isHoliday = false;
                    isHrExpanded = !isHrExpanded;
                  });
                },
                isSelected: idx == widget.currentIndex,
                controller: _controllers[idx],
              ),
            ),
          ],
        ),
        if (isHrExpanded) ...[
          NavigationHRItem(
            text: 'Leave',
            isTapped: isLeave,
            color: isLeave ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isLeave = true;
                user_repo.localDB.value.isAttendance = false;
                user_repo.localDB.value.isHoliday = false;
                user_repo.localDB.value.isAppreciation = false;
                isLeave = true;
                isAppri = false;
                isAttendence = false;
                isHoliday = false;
              });
            },
          ),
          NavigationHRItem(
            text: 'Attendance',
            isTapped: isAttendence,
            color: isAttendence ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isLeave = false;
                user_repo.localDB.value.isAttendance = true;
                user_repo.localDB.value.isHoliday = false;
                user_repo.localDB.value.isAppreciation = false;
                isLeave = false;
                isAppri = false;
                isAttendence = true;
                isHoliday = false;
              });
            },
          ),
          NavigationHRItem(
            text: 'Holiday',
            isTapped: isHoliday,
            color: isHoliday ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isLeave = false;
                user_repo.localDB.value.isAttendance = false;
                user_repo.localDB.value.isHoliday = true;
                user_repo.localDB.value.isAppreciation = false;
                isLeave = false;
                isAppri = false;
                isAttendence = false;
                isHoliday = true;
              });
            },
          ),
          NavigationHRItem(
            text: 'Appreciations',
            isTapped: isAppri,
            color: isAppri ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isLeave = false;
                user_repo.localDB.value.isAttendance = false;
                user_repo.localDB.value.isHoliday = false;
                user_repo.localDB.value.isAppreciation = true;
                isLeave = false;
                isAppri = true;
                isAttendence = false;
                isHoliday = false;
              });
            },
          ),
        ],
      ],
    );
  }

  Widget _buildWorkSection(int idx) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: NavigationItem(
                icon: Icons.work_outline,
                text: 'Work',
                isExpandable: true,
                onTap: () {
                  widget.onTabTapped(idx);
                  setState(() {
                    user_repo.localDB.value.isProjects = true;
                    user_repo.localDB.value.isTasks = false;
                    user_repo.localDB.value.isTimesheet = false;
                    user_repo.localDB.value.isProjectName = false;
                    isProjects = !isWorkExpanded;
                    isTasks = false;
                    isTimesheet = false;
                    isWorkExpanded = !isWorkExpanded;
                  });
                },
                isSelected: idx == widget.currentIndex,
                controller: _controllers[idx],
              ),
            ),
          ],
        ),
        if (isWorkExpanded) ...[
          NavigationHRItem(
            text: 'Projects',
            isTapped: isProjects,
            color: isProjects ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isProjects = true;
                user_repo.localDB.value.isTasks = false;
                user_repo.localDB.value.isTimesheet = false;
                user_repo.localDB.value.isProjectName = false;
                isProjects = true;
                isTasks = false;
                isTimesheet = false;
              });
            },
          ),
          NavigationHRItem(
            text: 'Tasks',
            isTapped: isTasks,
            color: isTasks ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isProjects = false;
                user_repo.localDB.value.isTasks = true;
                user_repo.localDB.value.isTimesheet = false;
                user_repo.localDB.value.isProjectName = false;
                isProjects = false;
                isTasks = true;
                isTimesheet = false;
              });
            },
          ),
          NavigationHRItem(
            text: 'Timesheet',
            isTapped: isTimesheet,
            color: isTimesheet ? Colors.black : Colors.grey,
            onTap: () {
              setState(() {
                user_repo.localDB.value.isProjects = false;
                user_repo.localDB.value.isTasks = false;
                user_repo.localDB.value.isTimesheet = true;
                user_repo.localDB.value.isProjectName = false;
                isProjects = false;
                isTasks = false;
                isTimesheet = true;
              });
            },
          ),
        ],
      ],
    );
  }
}
