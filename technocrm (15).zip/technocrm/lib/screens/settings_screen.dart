import 'package:flutter/foundation.dart' show Uint8List, kIsWeb;
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Settings_Widgets/profile_details_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/models_projects/project_progress_model.dart';
import 'dart:io';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  File? file;
  Uint8List? webImage;

  Future<void> pickImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: kIsWeb,
    );

    if (result != null) {
      if (kIsWeb) {
        setState(() {
          webImage = result.files.single.bytes;
        });
      } else {
        setState(() {
          file = File(result.files.single.path!);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ProjectProgressModel(
                    titleText: "Profile Setting",
                    subtitleText: "Setting",
                    subtitleText1: "Profile Setting"),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(
              height: 60,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 0, 0, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      CircleAvatar(
                        radius: 70,
                        backgroundColor: Colors.grey.shade300,
                        backgroundImage: webImage != null
                            ? MemoryImage(webImage!) as ImageProvider
                            : file != null
                                ? FileImage(file!) as ImageProvider
                                : const AssetImage('assets/avatar4.png'),
                      ),
                      Positioned(
                        bottom: 0,
                        child: Container(
                          height: 30,
                          width: 30,
                          decoration: const BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: pickImage,
                            child: const SizedBox(
                              width: 140,
                              height: 140,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            const ProfileDetailsWidget(),
          ],
        ),
      ),
    );
  }
}
