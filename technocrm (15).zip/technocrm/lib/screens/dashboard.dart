import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/clock_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_joining_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_leave_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_WFH_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_birthdays_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_employee_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_mytask_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_notice_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_profile_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_task_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_tickets_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/dashboard_timelog_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/page_titleWidget.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                PageTitleWidget(
                  titleText: "Dashboard",
                  subtitleText: "Dashboard",
                ),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                  child: Text(
                    "Welcome Harsh!",
                    style: TextStyle(
                      fontSize: 25,
                      color: AppColors.titleColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            "06:17 am",
                            style: TextStyle(
                              fontSize: 20,
                              color: AppColors.titleColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Thursday",
                            style: TextStyle(
                              fontSize: 15,
                              color: AppColors.titleColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      ClockWidget(
                          function: () {},
                          title: "Clock in",
                          icon: Icons.login,
                          color: Colors.blue),
                      const SizedBox(
                        width: 20,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(30.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.33,
                    child: const Column(
                      children: [
                        Column(
                          children: [
                            DashboardProfileWidget(),
                            SizedBox(
                              height: 30,
                            ),
                            birthdaywidget(),
                            SizedBox(
                              height: 30,
                            ),
                            employeeappreciationwidget(),
                            SizedBox(
                              height: 30,
                            ),
                            onleavewidget(),
                            SizedBox(
                              height: 30,
                            ),
                            workfromhomewidget(),
                            SizedBox(
                              height: 30,
                            ),
                            joiningandworkanniversarywidget()
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 30),
                  const Expanded(
                    child: Column(
                      children: [
                        Column(
                          children: [
                            taskandprojectwidget(),
                            SizedBox(
                              height: 30,
                            ),
                            WeekTimelogsWidget(),
                            SizedBox(
                              height: 30,
                            ),
                            MyTaskWidget(),
                            SizedBox(
                              height: 30,
                            ),
                            TicketsWidget(),
                            SizedBox(
                              height: 30,
                            ),
                            NoticesWidget(),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
