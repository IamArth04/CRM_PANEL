import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/pages/add_lead_info_page.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_companydetails_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_details_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_info_widget.dart';

class LeadsScreen extends StatefulWidget {
  const LeadsScreen({super.key});

  @override
  _LeadsScreenState createState() => _LeadsScreenState();
}

class _LeadsScreenState extends State<LeadsScreen> {
  bool _showAddLeadPage = false;

  void _onAddLeadTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const AddleadHeadtitleWidget(),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                ),
                Text(
                  "Lead Details",
                  style: TextStyle(
                    fontSize: 25,
                    color: AppColors.titleColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    LeadDetailsWidget(),
                    SizedBox(
                      height: 10,
                    ),
                    LeadContactDetailsWidget(),
                  ],
                ),
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  void _onBackToLeadsTap() {
    setState(() {
      _showAddLeadPage = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: _showAddLeadPage
          ? AddLeadInfoPage(onBackTap: _onBackToLeadsTap)
          : SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      LeadsPagetitleWidget(
                        titleText: "Leads",
                        subtitleText: "Leads",
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const LeadsHeadtitleWidget(),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 10, 0),
                    child: Row(
                      children: [
                        ButtonleadWidget(
                          title: "Add Lead",
                          icon: Icons.add,
                          color: Colors.blue,
                          function: () {
                            _onAddLeadTap(context);
                          },
                          Tcolor: Colors.white,
                        ),
                        const SizedBox(width: 10),
                        ButtonleadWidget(
                          title: "Import",
                          icon: Icons.drive_file_move_outline,
                          color: AppColors.bgColor,
                          function: () {},
                          Tcolor: Colors.grey,
                        ),
                        const SizedBox(width: 10),
                        ButtonleadWidget(
                          title: "Export",
                          icon: Icons.upload_file_outlined,
                          color: AppColors.bgColor,
                          function: () {},
                          Tcolor: Colors.grey,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  const LeadInfoWidget(),
                ],
              ),
            ),
    );
  }
}
