import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/page_titleWidget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Holiday/model_holiday/addevent_model.dart';

class EventsScreen extends StatefulWidget {
  const EventsScreen({super.key});

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> {
  late DateTime focusedDay;
  String selectedMonth = "September";
  final Color borderColor = const Color.fromARGB(255, 8, 45, 232);

  @override
  void initState() {
    super.initState();
    focusedDay = DateTime.now();
  }

  void _onMonthChanged(String selectedMonth) {
    int monthIndex = _getMonthIndex(selectedMonth);
    if (monthIndex != -1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        setState(() {
          focusedDay = DateTime(focusedDay.year, monthIndex);
        });
      });
    }
  }

  int _getMonthIndex(String monthName) {
    const monthNames = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return monthNames.indexOf(monthName) + 1;
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                PageTitleWidget(
                  titleText: "Events",
                  subtitleText: "Events",
                ),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.fromLTRB(30, 10, 30, 30),
              margin: const EdgeInsets.fromLTRB(30, 0, 90, 0),
              decoration: const BoxDecoration(
                color: Colors.white,
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            "$selectedMonth ${focusedDay.year}",
                            style: const TextStyle(
                                fontSize: 26, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(width: 20),
                          SizedBox(
                            width: 125,
                            height: 30,
                            child: DropdownButtonFormField<String>(
                              value: selectedMonth,
                              icon: Icon(
                                Icons.keyboard_arrow_down_sharp,
                                color: borderColor,
                              ),
                              decoration: InputDecoration(
                                contentPadding: const EdgeInsets.symmetric(
                                    vertical: 5, horizontal: 10),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2),
                                  borderSide: BorderSide(
                                    color: borderColor,
                                    width: 1,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2),
                                  borderSide: BorderSide(
                                    color: borderColor,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2),
                                  borderSide: BorderSide(
                                    color: borderColor,
                                    width: 1,
                                  ),
                                ),
                              ),
                              items: [
                                'January',
                                'February',
                                'March',
                                'April',
                                'May',
                                'June',
                                'July',
                                'August',
                                'September',
                                'October',
                                'November',
                                'December',
                              ].map((month) {
                                return DropdownMenuItem<String>(
                                  value: month,
                                  child: Text(
                                    month,
                                    style: TextStyle(
                                      color: borderColor,
                                    ),
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) {
                                if (value != null) {
                                  _onMonthChanged(value);
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      AddeventButton(
                        title: 'Add Event',
                        color: borderColor,
                        textColor: Colors.white,
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icons.add_circle_outlined,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    height: size.height * 0.99,
                    child: SfCalendar(
                      view: CalendarView.month,
                      dataSource: _getCalendarDataSource(),
                      showDatePickerButton: true,
                      headerHeight: 0,
                      monthViewSettings: const MonthViewSettings(
                        appointmentDisplayMode:
                            MonthAppointmentDisplayMode.appointment,
                        showAgenda: true,
                        appointmentDisplayCount: 3,
                      ),
                      onViewChanged: (ViewChangedDetails details) {},
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _DataSource _getCalendarDataSource() {
    List<Appointment> appointments = <Appointment>[];

    appointments.add(Appointment(
      startTime: DateTime(2024, 1, 2, 8, 0, 0),
      endTime: DateTime(2024, 1, 2, 9, 0, 0),
      subject: 'Event Name',
      color: Colors.red,
    ));

    appointments.add(Appointment(
      startTime: DateTime(2024, 1, 2, 8, 0, 0),
      endTime: DateTime(2024, 1, 2, 9, 0, 0),
      subject: 'Event Name',
      color: Colors.green,
    ));

    appointments.add(Appointment(
      startTime: DateTime(2024, 1, 5, 9, 0, 0),
      endTime: DateTime(2024, 1, 5, 10, 0, 0),
      subject: 'Event Name',
      color: Colors.blue,
    ));

    appointments.add(Appointment(
      startTime: DateTime(2024, 1, 10, 8, 0, 0),
      endTime: DateTime(2024, 1, 10, 9, 0, 0),
      subject: 'Event Name',
      color: Colors.purple,
    ));

    appointments.add(Appointment(
      startTime: DateTime(2024, 1, 12, 8, 0, 0),
      endTime: DateTime(2024, 1, 12, 9, 0, 0),
      subject: 'Event Name',
      color: Colors.red,
    ));

    return _DataSource(appointments);
  }
}

class _DataSource extends CalendarDataSource {
  _DataSource(List<Appointment> source) {
    appointments = source;
  }
}
