import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Expenses_Widgets/drawer_expenses_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Tickets_widget.dart/createticket_widget.dart';
import 'package:technocrm/widgets/Tickets_widget.dart/head_tickets_info_widget.dart';
import 'package:technocrm/widgets/Tickets_widget.dart/list_tickets_widget.dart';

class TicketsScreen extends StatefulWidget {
  const TicketsScreen({super.key});

  @override
  State<TicketsScreen> createState() => _TicketsScreenState();
}

class _TicketsScreenState extends State<TicketsScreen> {
  void _onCreateTicketeTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Create Ticket",
            style: TextStyle(
              fontSize: 26,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.85,
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  "Ticket Details",
                  style: TextStyle(
                    fontSize: 22,
                    color: AppColors.titleColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                const CreateticketWidget(),
              ],
            ),
          ),
          actions: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    CustomButtonWidget(
                      title: 'Upload Files',
                      color: AppColors.bgColor,
                      textColor: Colors.blue,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icons.drive_folder_upload_outlined,
                    ),
                  ],
                ),
                Row(
                  children: [
                    CustomButtonWidget(
                      title: 'Cancel',
                      color: AppColors.bgColor,
                      textColor: Colors.grey,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icons.close,
                    ),
                    CustomButtonWidget(
                      title: 'Save',
                      color: Colors.blue,
                      textColor: Colors.white,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icons.check,
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(
                  titleText: "Tickets",
                  subtitleText: "Ticketsheet",
                ),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const DrawerExpensesWidget(),
            const SizedBox(height: 10),
            const HeadTicketsInfoWidget(),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.fromLTRB(35, 0, 10, 0),
              child: Row(
                children: [
                  ButtonleadWidget(
                    title: "Create Tickte",
                    icon: Icons.add,
                    color: Colors.blue,
                    function: () {
                      _onCreateTicketeTap(context);
                    },
                    Tcolor: Colors.white,
                  ),
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {},
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const ListTicketsWidget(),
          ],
        ),
      ),
    );
  }
}
