import 'dart:async';

import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/HomeInfo_project_work_widget.dart';
import 'package:technocrm/Models/Repository.dart' as user_repo;
import 'package:technocrm/widgets/Work_Widgets/Project_Widgets/inside_widget/project_name_work_widget.dart';
import 'package:technocrm/widgets/Work_Widgets/Tasks_Widgets/home_task_work_screen.dart';
import 'package:technocrm/widgets/Work_Widgets/Timesheet_Widget/home_timesheet_work_screen.dart';

class WorkScreen extends StatefulWidget {
  const WorkScreen({super.key});

  @override
  State<WorkScreen> createState() => _WorkScreenState();
}

class _WorkScreenState extends State<WorkScreen> {
  @override
  void initState() {
    stateRefresh();
    super.initState();
  }

  late Timer timer;

  void stateRefresh() {
    timer = Timer.periodic(const Duration(milliseconds: 400), (timer) {
      setState(() {});
    });
  }

  @override
  void dispose() {
    timer.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return user_repo.localDB.value.isProjects == true
        ? user_repo.localDB.value.isProjectName == false
            ? Scaffold(
                backgroundColor: AppColors.bgColor,
                body: SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          LeadsPagetitleWidget(
                              titleText: "Projects", subtitleText: "Projects"),
                          NotitficationWidget(),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const LeadsHeadtitleWidget(),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(27, 0, 10, 0),
                        child: Row(
                          children: [
                            const SizedBox(width: 10),
                            ButtonleadWidget(
                              title: "Export",
                              icon: Icons.upload_file_outlined,
                              color: AppColors.bgColor,
                              function: () {},
                              Tcolor: Colors.grey,
                            ),
                          ],
                        ),
                      ),
                      const InfoProjectWorkWidget(),
                    ],
                  ),
                ),
              )
            : const ProjectNameWorkWidget()
        : user_repo.localDB.value.isTasks == true
            ? const HomeTaskWorkScreen()
            : user_repo.localDB.value.isTimesheet == true
                ? const HomeTimesheetWorkScreen()
                : Container();
  }
}
