import 'dart:async';

import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Appreciation/home_appr_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Attendance/home_attendence_screen.dart';
import 'package:technocrm/widgets/HR_Widgets/Inside_Screen/Holiday/home_holiday_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/HR_Widgets/Info_hr_widget.dart';
import 'package:technocrm/widgets/HR_Widgets/LeavePageWidgets/newLeave_HR_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/Models/Repository.dart' as user_repo;
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';

class HrScreen extends StatefulWidget {
  const HrScreen({super.key});

  @override
  _HrScreenState createState() => _HrScreenState();
}

class _HrScreenState extends State<HrScreen> {
  void _onNewLeaveTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "New Leaves",
            style: TextStyle(
              fontSize: 26,
              color: AppColors.headtitleColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                ),
                Text(
                  "Assign Leave",
                  style: TextStyle(
                    fontSize: 25,
                    color: AppColors.titleColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const NewleaveHrWidget(),
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    stateRefresh();
    super.initState();
  }

  late Timer timer;

  void stateRefresh() {
    timer = Timer.periodic(const Duration(milliseconds: 400), (timer) {
      setState(() {});
    });
  }

  @override
  void dispose() {
    timer.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return user_repo.localDB.value.isLeave == true
        ? Scaffold(
            backgroundColor: AppColors.bgColor,
            body: SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      LeadsPagetitleWidget(
                          titleText: "Leaves", subtitleText: "Dashboard"),
                      NotitficationWidget(),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const LeadsHeadtitleWidget(),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 10, 0),
                    child: Row(
                      children: [
                        ButtonleadWidget(
                          title: "New Leave",
                          icon: Icons.add,
                          color: Colors.blue,
                          function: () {
                            _onNewLeaveTap(context);
                          },
                          Tcolor: Colors.white,
                        ),
                        const SizedBox(width: 10),
                        ButtonleadWidget(
                          title: "Export",
                          icon: Icons.upload_file_outlined,
                          color: AppColors.bgColor,
                          function: () {},
                          Tcolor: Colors.grey,
                        ),
                      ],
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(20, 10, 0, 0),
                    child: InfoHRWidget(),
                  ),
                ],
              ),
            ),
          )
        : user_repo.localDB.value.isAttendance == true
            ? const AttendenceScreen()
            : user_repo.localDB.value.isHoliday == true
                ? const HomeScreenHolidayWidget()
                : user_repo.localDB.value.isAppreciation == true
                    ? const HomeApprWidget()
                    : Container();
  }
}
