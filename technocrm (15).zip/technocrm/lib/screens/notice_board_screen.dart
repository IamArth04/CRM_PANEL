import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_bottombutton_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';
import 'package:technocrm/widgets/Notice_Board_Widgets/list_notice_board_widget.dart';
import 'package:technocrm/widgets/Notice_Board_Widgets/notice_details_widget.dart';

class NoticeBoardScreen extends StatefulWidget {
  const NoticeBoardScreen({super.key});

  @override
  State<NoticeBoardScreen> createState() => _NoticeBoardScreenState();
}

class _NoticeBoardScreenState extends State<NoticeBoardScreen> {
  void _onNoticeDetailsTap(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Notice Board",
                style: TextStyle(
                  fontSize: 26,
                  color: AppColors.headtitleColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.80,
                ),
                const SizedBox(
                  height: 20,
                ),
                const NoticeDetailsWidget(),
              ],
            ),
          ),
          actions: <Widget>[
            CustomButtonWidget(
              title: 'Cancel',
              color: AppColors.bgColor,
              textColor: Colors.grey,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.close,
            ),
            CustomButtonWidget(
              title: 'Save',
              color: Colors.blue,
              textColor: Colors.white,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icons.check,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(
                  titleText: "Notice Board",
                  subtitleText: "Notice Board",
                ),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const LeadsHeadtitleWidget(),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(27, 0, 10, 0),
              child: Row(
                children: [
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {
                      _onNoticeDetailsTap(context);
                    },
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const ListNoticeBoardWidget(),
          ],
        ),
      ),
    );
  }
}
