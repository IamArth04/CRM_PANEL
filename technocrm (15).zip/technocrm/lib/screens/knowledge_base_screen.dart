import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Dashboard_Widgets/notitficationWidget.dart';
import 'package:technocrm/widgets/Knowledge_base_widget/list_knowledge_base_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/laed_topbuttonlead_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_headtitle_widget.dart';
import 'package:technocrm/widgets/Leads_Widgets/lead_pagetitle_widget.dart';

class KnowledgeBaseScreen extends StatefulWidget {
  const KnowledgeBaseScreen({super.key});

  @override
  State<KnowledgeBaseScreen> createState() => _KnowledgeBaseScreenState();
}

class _KnowledgeBaseScreenState extends State<KnowledgeBaseScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                LeadsPagetitleWidget(
                  titleText: "Knowledge Base",
                  subtitleText: "Knowledge Base",
                ),
                NotitficationWidget(),
              ],
            ),
            const SizedBox(height: 10),
            const LeadsHeadtitleWidget(),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(27, 0, 10, 0),
              child: Row(
                children: [
                  const SizedBox(width: 10),
                  ButtonleadWidget(
                    title: "Export",
                    icon: Icons.upload_file_outlined,
                    color: AppColors.bgColor,
                    function: () {},
                    Tcolor: Colors.grey,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const ListKnowledgeBaseWidget(),
          ],
        ),
      ),
    );
  }
}
