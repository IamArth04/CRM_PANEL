import 'package:flutter/material.dart';
import 'package:technocrm/screens/dashboard.dart';
import 'package:technocrm/screens/events_screen.dart';
import 'package:technocrm/screens/expenses_screen.dart';
import 'package:technocrm/screens/hr_screen.dart';
import 'package:technocrm/screens/knowledge_base_screen.dart';
import 'package:technocrm/screens/leads_screen.dart';
import 'package:technocrm/screens/messages_screen.dart';
import 'package:technocrm/screens/notice_board_screen.dart';
import 'package:technocrm/screens/settings_screen.dart';
import 'package:technocrm/screens/tickets_screen.dart';
import 'package:technocrm/screens/work_screen.dart';
import 'package:technocrm/widgets/navigation_widget.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;
  final PageController _pageController = PageController();

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    _pageController.jumpToPage(index);
  }

  dynamic pages = [
    const Dashboard(),
    const LeadsScreen(),
    const HrScreen(),
    const WorkScreen(),
    const ExpensesScreen(),
    const TicketsScreen(),
    const EventsScreen(),
    const MessagesScreen(),
    const NoticeBoardScreen(),
    const KnowledgeBaseScreen(),
    const SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Row(
        children: [
          Navigation(
            currentIndex: _currentIndex,
            onTabTapped: _onTabTapped,
          ),
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (index) {
                setState(() {
                  _currentIndex = index;
                });
              },
              children: pages,
            ),
          ),
        ],
      ),
    );
  }
}
