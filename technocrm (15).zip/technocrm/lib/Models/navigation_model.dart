import 'package:flutter/material.dart';
import 'package:technocrm/controller/navigation_controller.dart';

class NavigationItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool isSelected;
  final NavigationController controller;
  final Widget? trailing;
  final bool isExpandable;

  const NavigationItem({
    super.key,
    required this.icon,
    required this.text,
    required this.onTap,
    required this.isSelected,
    required this.controller,
    this.isExpandable = false,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        controller.animate();
        onTap();
      },
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          return Transform.scale(
            scale: isSelected ? controller.scaleAnimation.value : 1.0,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 12.0, horizontal: 8.0),
              decoration: BoxDecoration(
                color: isSelected ? Colors.grey.shade300 : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(icon,
                      size: 24.0,
                      color: isSelected ? Colors.black : Colors.grey),
                  const SizedBox(width: 10),
                  Flexible(
                    child: Text(
                      text,
                      softWrap: false,
                      overflow: TextOverflow.fade,
                      style: TextStyle(
                          fontSize: 16,
                          color: isSelected ? Colors.black : Colors.grey),
                    ),
                  ),
                  Visibility(
                    visible: isExpandable,
                    child: const Icon(
                      Icons.expand_more,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
