import 'package:flutter/material.dart';
import 'package:technocrm/Controller/LocalDB.dart';

ValueNotifier<LocalDB> localDB = ValueNotifier<LocalDB>(LocalDB());
