import 'package:flutter/material.dart';

class AppColors {
  static Color titleColor = const Color.fromARGB(255, 0, 0, 72);
  static Color headtitleColor = const Color.fromARGB(255, 1, 52, 88);
  static Color textColor = const Color.fromARGB(255, 5, 43, 85);
  static Color bgColor = const Color.fromARGB(255, 222, 233, 241);
}
