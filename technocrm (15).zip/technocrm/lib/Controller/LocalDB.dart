class LocalDB {
  bool? isLeave,
      isAttendance,
      isHoliday,
      isAppreciation,
      isProjects,
      isTasks,
      isTimesheet,
      isProjectName;

  LocalDB(
      {this.isLeave = false,
      this.isAttendance = false,
      this.isHoliday = false,
      this.isAppreciation = false,
      this.isProjects = false,
      this.isTasks = false,
      this.isTimesheet = false,
      this.isProjectName = false});
}
