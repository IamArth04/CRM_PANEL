import 'package:flutter/material.dart';

class NavigationController extends ChangeNotifier {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<Color?> _colorAnimation;

  bool isSelected = false;

  NavigationController(TickerProvider vsync) {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: vsync,
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.1).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _colorAnimation =
        ColorTween(begin: Colors.black, end: Colors.black).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
  }

  Animation<double> get scaleAnimation => _scaleAnimation;
  Animation<Color?> get colorAnimation => _colorAnimation;

  void animate() {
    isSelected = true;
    notifyListeners();
    _animationController.forward().then((_) {
      _animationController.reverse().then((_) {
        isSelected = false;
        notifyListeners();
      });
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
