import 'package:flutter/material.dart';
import 'package:technocrm/Const/colorsConst.dart';
import 'package:technocrm/widgets/Leads_Widgets/Add_Lead_Info_Widgets/addlead_pagetitle_widget.dart';

class AddLeadInfoPage extends StatelessWidget {
  const AddLeadInfoPage({super.key, required void Function() onBackTap});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: const SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                AddleadPagetitleWidget(
                  titleText: "Leads",
                  subtitleText1: 'Home',
                  subtitleText2: 'Add Lead Info',
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
